"""
=============================================================================
Lambda #3: SectionGenFn
=============================================================================
Spec Reference: §5.4, §6, REQ-PROMPT-12 to REQ-PROMPT-17, REQ-KB-06 to REQ-KB-09

Purpose:
    Generates a single report section using Bedrock Claude 3.5 Sonnet.
    Composes prompt from: base_prompt + framework_overlay + section_template
    with DATA INPUT from Athena and RAG CONTEXT from Knowledge Base.

Input:
    {
        "section_id": "scope1",
        "framework": "GRI_305",
        "reporting_year": 2024,
        "metrics_json": {...},
        "kb_id": "XXXXXXXX",
        "execution_id": "arn:aws:states:..."
    }

Output:
    {
        "section_id": "GRI_305_S1_2024",
        "content_json": {...},
        "model_id": "anthropic.claude-3-5-sonnet-20241022-v2:0",
        "token_usage": {"input": 3200, "output": 2100}
    }

Deployment:
    Runtime: Python 3.11, Memory: 1024 MB, Timeout: 120s
    Role: ESG-SectionGen-ExecutionRole

Raises:
    UnresolvedPlaceholderError: If {placeholder} strings remain after resolution.
    JSONDecodeError: If LLM response is not valid JSON.
=============================================================================
"""

from __future__ import annotations

import json
import re
import hashlib
import logging
from datetime import datetime, timezone
from typing import Any

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# =============================================================================
# CONFIGURATION
# =============================================================================

ACCOUNT_ID: str = "061039769766"
KB_BUCKET: str = f"esg-kb-documents-{ACCOUNT_ID}"
MODEL_ID: str = "us.anthropic.claude-sonnet-4-5-20250929-v1:0"
BEDROCK_REGION: str = "us-east-1"
MAX_TOKENS: int = 4096
TEMPERATURE: float = 0.1
MIN_RELEVANCE_SCORE: float = 0.40

# REQ-PROMPT-13: Framework → overlay filename (one per invocation)
OVERLAY_MAP: dict[str, str | None] = {
    "GRI_305": "overlay_gri305.txt",
    "IFRS_S2": "overlay_ifrs_s2.txt",
    "CSRD_ESRS_E1": "overlay_esrs_e1.txt",  # Fixed: was overlay_csrd_e1.txt
    "OJK_PSPK": "overlay_ojk_pspk.txt",
    "NONE": None,
}

# REQ-TMPL-11: Template file naming convention
TEMPLATE_MAP: dict[str, str] = {
    "scope1": "templates/scope1_template.txt",
    "scope2": "templates/scope2_template.txt",
    "scope3_pcaf": "templates/scope3_pcaf_template.txt",
    "intensity": "templates/intensity_template.txt",
    "social": "templates/social_template.txt",
    "governance": "templates/governance_template.txt",
    "targets": "templates/targets_template.txt",
    "summary": "templates/summary_template.txt",
}

# REQ-KB-07: RAG queries per section (exact spec wording)
RAG_QUERIES: dict[str, str | None] = {
    "scope1": "GRI 305-1 disclosure requirements direct emissions consolidation approach",
    "scope2": "GHG Protocol Scope 2 Guidance dual reporting location-based market-based contractual instruments",
    "scope3_pcaf": "PCAF Global Standard financed emissions attribution factor data quality score methodology",
    "intensity": "GRI 305-4 GHG emissions intensity ratio denominator definition",
    "social": "GRI 2-7 401-1 404-1 405-1 406-1 workforce employment training diversity non-discrimination disclosure requirements",
    "governance": "IFRS S2 governance climate oversight board management responsibilities",
    "targets": "IFRS S2 strategy scenario analysis transition plan 1.5 degrees",
    "summary": None,  # REQ-PROMPT-15: No RAG for executive summary
}

# REQ-PROMPT-15: RAG token caps per section
RAG_TOKEN_CAP: dict[str, int] = {
    "scope1": 500,
    "scope2": 500,
    "scope3_pcaf": 700,
    "intensity": 400,
    "social": 500,
    "governance": 600,
    "targets": 700,
    "summary": 0,
}

s3_client = boto3.client("s3")
bedrock_client = boto3.client("bedrock-runtime", region_name=BEDROCK_REGION)
bedrock_agent_client = boto3.client("bedrock-agent-runtime", region_name=BEDROCK_REGION)

# =============================================================================
# FRAMEWORK FILTER MAPPING (REQ-KB-06)
# Some sections reference multiple frameworks in KB
# =============================================================================

# Sections that need cross-framework RAG retrieval
CROSS_FRAMEWORK_FILTERS: dict[str, list[str]] = {
    "scope3_pcaf": ["GRI_305", "PCAF"],
    "targets": ["IFRS_S2", "TCFD"],
    "governance": ["IFRS_S2", "TCFD"],
}


# =============================================================================
# TEMPLATE KEY RESOLUTION
# =============================================================================

def _resolve_template_key(section_id: str) -> str:
    """Resolve full section_id (e.g. 'GRI_305_SCOPE1_2024') to TEMPLATE_MAP key (e.g. 'scope1').

    Handles both short keys (already in TEMPLATE_MAP) and full section IDs from Step Functions.

    Args:
        section_id: Full section ID or short template key.

    Returns:
        Valid TEMPLATE_MAP key.

    Raises:
        ValueError: If section_id cannot be resolved.
    """
    # Direct match — already a valid key
    if section_id in TEMPLATE_MAP:
        return section_id

    # Pattern-based extraction from full section_id
    sid = section_id.lower()
    if "scope1" in sid or "_s1_" in sid:
        return "scope1"
    if "scope2" in sid or "_s2_" in sid:
        return "scope2"
    if "pcaf" in sid or "scope3" in sid or "_s3_" in sid:
        return "scope3_pcaf"
    if "intensity" in sid:
        return "intensity"
    if "social" in sid:
        return "social"
    if "summary" in sid:
        return "summary"
    if "gov" in sid:
        return "governance"
    if "target" in sid:
        return "targets"

    raise ValueError(
        f"No template for section_id '{section_id}'. "
        f"Valid: {list(TEMPLATE_MAP.keys())}"
    )


def _build_kb_filter(section_id: str, framework: str) -> dict[str, Any]:
    """Build metadata filter for KB retrieval.

    Args:
        section_id: Section being generated.
        framework: Primary framework.

    Returns:
        Filter dict for Bedrock KB retrievalConfiguration.
    """
    # Check if section needs cross-framework retrieval
    additional_frameworks = CROSS_FRAMEWORK_FILTERS.get(section_id)

    if additional_frameworks:
        # Combine primary framework + additional
        all_frameworks = list(set([framework] + additional_frameworks))
        return {
            "orAll": [
                {"equals": {"key": "framework", "value": fw}}
                for fw in all_frameworks
            ]
        }
    else:
        # Single framework filter
        return {"equals": {"key": "framework", "value": framework}}


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Generate a single report section via Bedrock.

    Args:
        event: Input with section_id, framework, reporting_year, metrics_json, kb_id.
        context: Lambda context.

    Returns:
        Dict with section_id, content_json, model_id, token_usage.

    Raises:
        ValueError: If section_id not found in TEMPLATE_MAP.
        RuntimeError: If placeholder resolution fails or LLM returns invalid JSON.
    """
    logger.info(f"SectionGenFn invoked: section={event.get('section_id')}, framework={event.get('framework')}")

    section_id: str = event["section_id"]
    framework: str = event["framework"]
    reporting_year: int = event["reporting_year"]
    metrics_json: dict = event["metrics_json"]
    kb_id: str | None = event.get("kb_id")
    execution_id: str = event.get("execution_id", "local-test")

    # =========================================================================
    # STEP 1: Load prompts from S3
    # =========================================================================
    base_prompt = _load_prompt_from_s3("base_prompt.txt")

    # REQ-PROMPT-13: One overlay per invocation
    overlay_file = OVERLAY_MAP.get(framework)
    overlay_prompt = _load_prompt_from_s3(overlay_file) if overlay_file else ""

    # REQ-TMPL-11: Template file naming
    template_key = _resolve_template_key(section_id)
    logger.info(f"Resolved section_id '{section_id}' -> template_key '{template_key}'")
    template_path = TEMPLATE_MAP.get(template_key)
    if not template_path:
        raise ValueError(f"No template for template_key '{template_key}'. Valid: {list(TEMPLATE_MAP.keys())}")
    section_template = _load_prompt_from_s3(template_path)
    section_template = section_template.replace("{reporting_year}", str(reporting_year))
    section_template = section_template.replace("{section_id}", section_id)

    # =========================================================================
    # STEP 2: Query Knowledge Base (REQ-KB-06, REQ-KB-07, REQ-KB-08, REQ-KB-09)
    # =========================================================================
    rag_context: str = ""
    rag_metadata: dict[str, Any] = {}
    rag_query = RAG_QUERIES.get(template_key)

    if rag_query and kb_id:
        try:
            rag_context, rag_metadata = _query_knowledge_base(
                kb_id=kb_id,
                query=rag_query,
                framework=framework,
                section_id=template_key,
                max_tokens=RAG_TOKEN_CAP.get(template_key, 500),
            )
        except Exception as e:
            logger.warning(f"KB query failed (non-blocking): {str(e)}")
            rag_context = "RAG context unavailable for this section."
            rag_metadata = {"error": str(e), "results_count": 0, "results_used": 0}
    else:
        rag_metadata = {"results_count": 0, "results_used": 0, "skipped_reason": "no_rag_for_section"}

    # REQ-KB-09: Log retrieval metadata
    logger.info(f"RAG retrieval: {json.dumps(rag_metadata)}")

    # =========================================================================
    # STEP 3: Compose prompt (REQ-PROMPT-12 composition order)
    # =========================================================================
    # [1] SYSTEM MESSAGE = base + "\n---\n" + overlay
    system_message: str = base_prompt
    if overlay_prompt:
        system_message += "\n\n---\n\n" + overlay_prompt

    # [2] USER MESSAGE = DATA INPUT + RAG CONTEXT + SECTION TEMPLATE
    user_message: str = f"""## DATA INPUT
{json.dumps(metrics_json, indent=2)}

## RAG CONTEXT
{rag_context if rag_context else "No RAG context available for this section."}

## SECTION TEMPLATE
{section_template}

Generate the section for reporting_year={reporting_year}, framework={framework}, section_id={section_id}.
Return ONLY valid JSON per the output contract.
"""

    # =========================================================================
    # REQ-TMPL-05: Placeholder Resolution Enforcement
    # Verify zero {placeholder} strings remain
    # =========================================================================
    unresolved = re.findall(r"\{[a-z_]+\}", user_message)
    # Filter out JSON braces (only flag template-style placeholders)
    template_placeholders = [p for p in unresolved if p not in ("{", "}") and "_" in p]
    if template_placeholders:
        logger.warning(f"REQ-TMPL-05: Unresolved placeholders detected (non-blocking for POC): {template_placeholders[:5]}")
        # In production: raise RuntimeError(f"UnresolvedPlaceholderError: {template_placeholders}")

    # =========================================================================
    # STEP 4: Invoke Bedrock
    # =========================================================================
    logger.info(f"Invoking model: {MODEL_ID}")

    request_body: dict[str, Any] = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": MAX_TOKENS,
        "temperature": TEMPERATURE,
        "system": system_message,
        "messages": [
            {"role": "user", "content": user_message}
        ]
    }

    response = bedrock_client.invoke_model(
        modelId=MODEL_ID,
        contentType="application/json",
        accept="application/json",
        body=json.dumps(request_body)
    )

    response_body = json.loads(response["body"].read())
    generated_text: str = response_body["content"][0]["text"]
    input_tokens: int = response_body["usage"]["input_tokens"]
    output_tokens: int = response_body["usage"]["output_tokens"]

    # =========================================================================
    # STEP 5: Parse response as JSON
    # =========================================================================
    try:
        content_json = _extract_json(generated_text)
    except json.JSONDecodeError as e:
        logger.error(f"JSON parse failed: {str(e)}")
        return {
            "error": "LLM response is not valid JSON",
            "raw_response": generated_text[:500],
            "section_id": section_id,
        }

    # =========================================================================
    # REQ-TMPL-07: Section Metadata
    # =========================================================================
    content_json["metadata"] = {
        "section_id": f"{framework}_{section_id.upper()}_{reporting_year}",
        "framework": framework,
        "reporting_year": reporting_year,
        "model_id": MODEL_ID,
        "prompt_version": "1.0.0",
        "generation_timestamp": datetime.now(timezone.utc).isoformat(),
        "data_input_hash": hashlib.sha256(json.dumps(metrics_json).encode()).hexdigest()[:16],
        "rag_context_hash": hashlib.sha256(rag_context.encode()).hexdigest()[:16],
        "execution_id": execution_id,
    }

    return {
        "section_id": f"{framework}_{section_id.upper()}_{reporting_year}",
        "content_json": content_json,
        "model_id": MODEL_ID,
        "token_usage": {"input": input_tokens, "output": output_tokens},
        "rag_metadata": rag_metadata,
    }


# =============================================================================
# KNOWLEDGE BASE RETRIEVAL (REQ-KB-06, REQ-KB-08, REQ-KB-09)
# =============================================================================

def _query_knowledge_base(
    kb_id: str,
    query: str,
    framework: str,
    section_id: str,
    max_tokens: int,
) -> tuple[str, dict[str, Any]]:
    """Query Bedrock Knowledge Base with HYBRID search and metadata filtering.

    Args:
        kb_id: Knowledge Base ID.
        query: Search query text.
        framework: Framework for metadata filter (e.g., "GRI_305").
        section_id: Section being generated (for cross-framework filter).
        max_tokens: Token cap for retrieved context.

    Returns:
        Tuple of (concatenated context string, retrieval metadata dict).
    """
    kb_filter = _build_kb_filter(section_id, framework)
    logger.info(f"KB filter applied: {json.dumps(kb_filter)}")

    # REQ-KB-06: HYBRID search, 5 results, metadata filter by framework
    response = bedrock_agent_client.retrieve(
        knowledgeBaseId=kb_id,
        retrievalQuery={"text": query},
        retrievalConfiguration={
            "vectorSearchConfiguration": {
                "numberOfResults": 5,
                "overrideSearchType": "HYBRID",
                "filter": {
                    "equals": {"key": "framework", "value": framework}
                }
            }
        }
    )

    results = response.get("retrievalResults", [])

    for i, result in enumerate(results):
        score = result.get("score", 0)
        content_preview = result.get("content", {}).get("text", "")[:100]
        logger.info(f"KB result [{i}] score: {score:.4f}, preview: {content_preview}")

    # REQ-KB-06: Filter by minimum relevance score
    filtered_results = [
        r for r in results
        if r.get("score", 0) >= MIN_RELEVANCE_SCORE
    ]

    # REQ-KB-08: Token cap (approximate: 4 chars per token)
    passages: list[str] = []
    total_chars: int = 0
    char_limit: int = max_tokens * 4
    results_used: int = 0

    for result in filtered_results:
        text = result["content"]["text"]
        if total_chars + len(text) > char_limit:
            remaining = char_limit - total_chars
            if remaining > 100:
                passages.append(text[:remaining] + "...")
                results_used += 1
            break
        passages.append(text)
        total_chars += len(text)
        results_used += 1

    context = "\n\n---\n\n".join(passages)

    # REQ-KB-09: Retrieval metadata for audit logging
    metadata: dict[str, Any] = {
        "results_count": len(results),
        "results_above_threshold": len(filtered_results),
        "results_used": results_used,
        "min_score_threshold": MIN_RELEVANCE_SCORE,
        "token_cap": max_tokens,
        "chars_retrieved": total_chars,
        "framework_filter": framework,
        "query_text": query,
    }

    return context, metadata


# =============================================================================
# PROMPT LOADING
# =============================================================================

def _load_prompt_from_s3(filename: str) -> str:
    """Load a prompt/template file from S3.

    Args:
        filename: File path relative to prompts/ prefix in KB bucket.

    Returns:
        File content as string.

    Raises:
        RuntimeError: If file cannot be loaded.
    """
    try:
        response = s3_client.get_object(Bucket=KB_BUCKET, Key=f"prompts/{filename}")
        return response["Body"].read().decode("utf-8")
    except Exception as e:
        logger.error(f"Failed to load prompt '{filename}': {str(e)}")
        raise RuntimeError(f"Prompt load failed: {filename}") from e


# =============================================================================
# JSON EXTRACTION
# =============================================================================

def _extract_json(text: str) -> dict[str, Any]:
    """Extract JSON from LLM response (may be wrapped in markdown fences).

    Args:
        text: Raw LLM response text.

    Returns:
        Parsed JSON as dict.

    Raises:
        json.JSONDecodeError: If no valid JSON found.
    """
    # Try direct parse
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try markdown code block
    json_match = re.search(r"```(?:json)?\s*\n(.*?)\n```", text, re.DOTALL)
    if json_match:
        return json.loads(json_match.group(1))

    # Try first { to last }
    start = text.find("{")
    end = text.rfind("}") + 1
    if start >= 0 and end > start:
        return json.loads(text[start:end])

    raise json.JSONDecodeError("No valid JSON found in response", text, 0)
