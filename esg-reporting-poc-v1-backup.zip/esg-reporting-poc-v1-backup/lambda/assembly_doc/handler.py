"""
=============================================================================
Lambda #5: AssemblyDocFn
=============================================================================
Spec Reference: §8 (REQ-ASSY-01 to REQ-ASSY-14), REQ-TRACE-02, REQ-TRACE-05

Purpose:
    Assembles validated section JSONs into a formatted DOCX report.
    CON-ASSY-01: Zero LLM invocations — deterministic assembly only.

Input:
    {
        "sections": [{"section_id": "...", "content_json": {...}, "framework": "..."}],
        "output_bucket": "esg-output-reports-061039769766",
        "reporting_year": 2024,
        "bank_id": "GENERIC_FI_001",
        "framework": "GRI_305",
        "execution_id": "arn:aws:states:...",
        "generation_timestamp": "2026-06-03T12:00:00Z"  (for reproducibility REQ-ASSY-14)
    }

Output:
    {
        "s3_path": "s3://...",
        "page_count": 12,
        "file_size_kb": 145.3,
        "sections_assembled": 4,
        "generation_timestamp": "..."
    }

Deployment:
    Runtime: Python 3.11, Memory: 1024 MB, Timeout: 120s
    Role: ESG-AssemblyDoc-ExecutionRole
    Layer: python-docx

Raises:
    AssemblyError: If section content is invalid or DOCX creation fails.
=============================================================================
"""

from __future__ import annotations

import json
import os
import logging
from datetime import datetime, timezone
from typing import Any

import boto3
from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# =============================================================================
# CONFIGURATION
# =============================================================================

ACCOUNT_ID: str = "061039769766"
DEFAULT_OUTPUT_BUCKET: str = f"esg-output-reports-{ACCOUNT_ID}"

# §8.1: Document styling (NON-NEGOTIABLE spec values)
STYLE: dict[str, Any] = {
    "font_body": "Arial",
    "font_heading": "Arial",
    "font_size_body": 11,
    "font_size_h1": 18,
    "font_size_h2": 14,
    "font_size_h3": 12,
    "font_size_header_footer": 9,
    "font_size_table": 9,
    "font_size_footnote": 9,
    "font_size_framework_ref": 9,
    "color_h1": RGBColor(0x1B, 0x3A, 0x6B),
    "color_h2": RGBColor(0x3D, 0x60, 0x94),
    "color_h3": RGBColor(0x4A, 0x7A, 0xB5),
    "color_footer": RGBColor(0x80, 0x80, 0x80),
    "color_table_header_bg": RGBColor(0x1B, 0x3A, 0x6B),  # Navy header
    "color_table_header_text": RGBColor(0xFF, 0xFF, 0xFF),
    "color_table_alt_row": RGBColor(0xF2, 0xF6, 0xFC),    # Alternating rows
    "page_width": Inches(8.27),
    "page_height": Inches(11.69),
    "margin": Cm(2.54),
    "line_spacing": 1.15,
    "spacing_after_body_pt": 8,
    "spacing_before_h1_pt": 24,
    "spacing_after_h1_pt": 12,
    "spacing_before_h2_pt": 18,
    "spacing_after_h2_pt": 8,
}

# REQ-ASSY-09: Section ordering per framework
SECTION_ORDER: dict[str, list[str]] = {
    "GRI_305": ["scope1", "scope2", "scope3_pcaf", "intensity", "reduction"],
    "IFRS_S2": ["governance", "strategy", "risk_mgmt", "scope1", "scope3_pcaf", "metrics_targets"],
    "CSRD_ESRS_E1": ["e1_1_transition", "e1_5_energy", "e1_6_ghg", "scope1", "scope3_pcaf", "e1_9_financial"],
    "OJK_PSPK": ["env_metrics", "scope1", "scope3_pcaf", "social_metrics", "gov_metrics"],
    "MULTI_FRAMEWORK": ["scope1", "scope2", "scope3_pcaf", "intensity", "summary"],
}

# REQ-ASSY-10: Sections that get page breaks BEFORE them
PAGE_BREAK_BEFORE: set[str] = {"scope1", "scope2", "scope3_pcaf", "summary", "governance"}

s3_client = boto3.client("s3")


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Assemble validated sections into DOCX and save to S3.

    CON-ASSY-01: This function performs ZERO LLM invocations.

    Args:
        event: Input with sections, output_bucket, metadata.
        context: Lambda context.

    Returns:
        Dict with s3_path, page_count, file_size_kb, sections_assembled.
    """
    logger.info(f"AssemblyDocFn invoked: {len(event.get('sections', []))} sections")

    sections: list[dict] = event["sections"]
    output_bucket: str = event.get("output_bucket", DEFAULT_OUTPUT_BUCKET)
    reporting_year: int = event["reporting_year"]
    bank_id: str = event.get("bank_id", "GENERIC_FI_001")
    framework: str = event.get("framework", "MULTI_FRAMEWORK")
    execution_id: str = event.get("execution_id", "local-test")

    # REQ-ASSY-14: Accept timestamp as input for reproducibility
    ts_str = event.get("generation_timestamp")
    timestamp = datetime.fromisoformat(ts_str) if ts_str else datetime.now(timezone.utc)
    ts_short = timestamp.strftime("%Y%m%d_%H%M%S")

    # =========================================================================
    # REQ-ASSY-09: Sort sections per framework order
    # =========================================================================
    order = SECTION_ORDER.get(framework, SECTION_ORDER["MULTI_FRAMEWORK"])
    sections = _sort_sections(sections, order)

    # =========================================================================
    # Create document (§8.1)
    # =========================================================================
    doc = Document()

    for section in doc.sections:
        section.page_width = STYLE["page_width"]
        section.page_height = STYLE["page_height"]
        section.top_margin = STYLE["margin"]
        section.bottom_margin = STYLE["margin"]
        section.left_margin = STYLE["margin"]
        section.right_margin = STYLE["margin"]
        # REQ-ASSY-07: Cover page has no header/footer
        section.different_first_page_header_footer = True

    # =========================================================================
    # REQ-ASSY-06: Cover page
    # =========================================================================
    _add_cover_page(doc, bank_id, framework, reporting_year, timestamp, execution_id)

    # =========================================================================
    # REQ-ASSY-11: Table of Contents
    # =========================================================================
    _add_toc(doc)

    # =========================================================================
    # Header/Footer (§8.1) — applies to non-first pages
    # =========================================================================
    for section in doc.sections:
        # Header: right-aligned
        header = section.header
        h_para = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
        h_para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        run = h_para.add_run(f"{bank_id} | Reporting Year {reporting_year}")
        run.font.name = STYLE["font_body"]
        run.font.size = Pt(STYLE["font_size_header_footer"])

        # Footer: Left title | Right Page X of Y
        footer = section.footer
        f_para = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        f_para.alignment = WD_ALIGN_PARAGRAPH.LEFT
        run_l = f_para.add_run(f"ESG Report {framework} {reporting_year}")
        run_l.font.name = STYLE["font_body"]
        run_l.font.size = Pt(STYLE["font_size_header_footer"])
        run_l.font.color.rgb = STYLE["color_footer"]
        f_para.add_run("\t\t")
        _add_page_number_field(f_para)

    # =========================================================================
    # Assemble sections
    # =========================================================================
    sections_assembled: int = 0

    for section_data in sections:
        content = section_data.get("content_json", {})
        if not content:
            logger.warning(f"Skipping empty section: {section_data.get('section_id')}")
            continue

        sec_type = _extract_section_type(section_data.get("section_id", ""))

        # REQ-ASSY-10: Page break logic
        if sec_type in PAGE_BREAK_BEFORE and sections_assembled > 0:
            doc.add_page_break()

        # REQ-ASSY-12: Section title → Heading 1
        title = content.get("title", section_data.get("section_id", "Untitled"))
        heading = doc.add_heading(title, level=1)
        _style_heading(heading, level=1)

        # Paragraphs
        for para_data in content.get("paragraphs", []):
            text = para_data.get("text", "")
            para_type = para_data.get("paragraph_type", "narrative")
            p = doc.add_paragraph(text)
            _style_paragraph(p, para_type)

        # Tables (REQ-ASSY-03: custom ESG table style)
        for table_data in content.get("tables", []):
            _add_esg_table(doc, table_data)

        # REQ-ASSY-12: framework_references rendered inline (9pt parenthetical)
        fw_refs = content.get("framework_references", [])
        if fw_refs:
            ref_text = "Framework references: " + "; ".join(fw_refs)
            p = doc.add_paragraph()
            run = p.add_run(ref_text)
            run.font.size = Pt(STYLE["font_size_framework_ref"])
            run.font.italic = True
            run.font.color.rgb = STYLE["color_h2"]

        # REQ-ASSY-12: Footnotes preceded by horizontal rule
        footnotes = content.get("footnotes", [])
        if footnotes:
            _add_horizontal_rule(doc)
            for fn in footnotes:
                p = doc.add_paragraph(fn)
                _style_paragraph(p, "footnote")

        sections_assembled += 1

    # =========================================================================
    # REQ-ASSY-13: Appendices
    # =========================================================================
    _add_appendices(doc, sections, framework)

    # =========================================================================
    # REQ-TRACE-02: Document properties
    # =========================================================================
    props = doc.core_properties
    props.author = f"ESG Reporting System ({bank_id})"
    props.title = f"ESG Sustainability Report {reporting_year} - {framework}"
    props.subject = f"GHG Emissions Disclosure - {framework}"
    props.keywords = f"ESG, GHG, {framework}, {reporting_year}, PCAF, Scope1, Scope2, Scope3"
    props.comments = f"Generated by execution: {execution_id}"
    props.category = "ESG Sustainability Report"

    # =========================================================================
    # Save + Upload (REQ-TRACE-05)
    # =========================================================================
    filename = f"ESG_Report_{framework}_{reporting_year}_{ts_short}.docx"
    s3_key = f"reports/year={reporting_year}/{framework}/{filename}"
    tmp_path = f"/tmp/{filename}"

    doc.save(tmp_path)
    file_size_kb = round(os.path.getsize(tmp_path) / 1024, 1)

    s3_client.upload_file(
        Filename=tmp_path,
        Bucket=output_bucket,
        Key=s3_key,
        ExtraArgs={
            "ServerSideEncryption": "aws:kms",
            "Tagging": (
                f"esg:framework={framework}"
                f"&esg:reporting_year={reporting_year}"
                f"&esg:bank_id={bank_id}"
                f"&esg:execution_id={execution_id}"
                f"&esg:generated_at={timestamp.isoformat()}"
                f"&esg:sections_count={sections_assembled}"
                f"&esg:file_size_kb={file_size_kb}"
                f"&esg:status=draft"
            ),
        },
    )

    s3_path = f"s3://{output_bucket}/{s3_key}"
    logger.info(f"✅ Report: {s3_path} ({file_size_kb} KB, {sections_assembled} sections)")

    os.remove(tmp_path)

    return {
        "s3_path": s3_path,
        "page_count": sections_assembled + 2,  # cover + TOC + sections
        "file_size_kb": file_size_kb,
        "sections_assembled": sections_assembled,
        "generation_timestamp": timestamp.isoformat(),
    }


# =============================================================================
# SECTION ORDERING (REQ-ASSY-09)
# =============================================================================

def _sort_sections(sections: list[dict], order: list[str]) -> list[dict]:
    """Sort sections by framework-defined order.

    Args:
        sections: Unsorted section list.
        order: Framework-specific section order.

    Returns:
        Sorted sections list. Unknown sections appended at end.
    """
    order_map = {s: i for i, s in enumerate(order)}
    return sorted(
        sections,
        key=lambda s: order_map.get(_extract_section_type(s.get("section_id", "")), 999)
    )


# =============================================================================
# COVER PAGE (REQ-ASSY-06, REQ-ASSY-07)
# =============================================================================

def _add_cover_page(
    doc: Document, bank_id: str, framework: str, year: int,
    timestamp: datetime, execution_id: str
) -> None:
    """Add formatted cover page with confidentiality notice.

    Args:
        doc: Document instance.
        bank_id: Institution ID.
        framework: Report framework.
        year: Reporting year.
        timestamp: Generation timestamp.
        execution_id: Step Functions ARN.
    """
    # Logo placeholder
    doc.add_paragraph()
    p_logo = doc.add_paragraph("[INSTITUTION LOGO]")
    p_logo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in p_logo.runs:
        run.font.size = Pt(12)
        run.font.color.rgb = RGBColor(0x99, 0x99, 0x99)

    doc.add_paragraph()
    doc.add_paragraph()

    # Title
    title = doc.add_heading("ESG Sustainability Report", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _style_heading(title, level=1)

    subtitle = doc.add_heading(f"Reporting Year {year}", level=2)
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _style_heading(subtitle, level=2)

    doc.add_paragraph()

    # Metadata
    meta_items = [
        ("Institution", bank_id),
        ("Framework", framework),
        ("Generated", timestamp.strftime("%Y-%m-%d %H:%M UTC")),
        ("Status", "DRAFT — Subject to Review"),
        ("Assurance Level", "None"),
    ]
    for label, value in meta_items:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"{label}: {value}")
        run.font.name = STYLE["font_body"]
        run.font.size = Pt(STYLE["font_size_body"])

    doc.add_paragraph()
    doc.add_paragraph()

    # Confidentiality notice
    conf = doc.add_paragraph()
    conf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = conf.add_run(
        "CONFIDENTIAL — This document is for internal review purposes only. "
        "Do not distribute without authorization."
    )
    run.font.size = Pt(9)
    run.font.italic = True
    run.font.color.rgb = RGBColor(0x99, 0x33, 0x33)

    doc.add_page_break()


# =============================================================================
# TABLE OF CONTENTS (REQ-ASSY-11)
# =============================================================================

def _add_toc(doc: Document) -> None:
    """Add Table of Contents field code."""
    toc_heading = doc.add_heading("Table of Contents", level=1)
    _style_heading(toc_heading, level=1)

    # TOC field code (Word auto-generates on open)
    paragraph = doc.add_paragraph()
    run = paragraph.add_run()
    fld_char_begin = OxmlElement("w:fldChar")
    fld_char_begin.set(qn("w:fldCharType"), "begin")
    run._r.append(fld_char_begin)

    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = ' TOC \\o "1-3" \\h \\z \\u '
    run._r.append(instr)

    fld_char_end = OxmlElement("w:fldChar")
    fld_char_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char_end)

    doc.add_paragraph("(Update this field in Word: Ctrl+A → F9)")
    doc.add_page_break()


# =============================================================================
# HEADING STYLING (§8.1, REQ-ASSY-02)
# =============================================================================

def _style_heading(heading, level: int = 1) -> None:
    """Apply spec heading style with keep_with_next and spacing.

    Args:
        heading: Heading paragraph.
        level: 1, 2, or 3.
    """
    # REQ-ASSY-02: keep_with_next prevents orphaned headings
    heading.paragraph_format.keep_with_next = True

    if level == 1:
        heading.paragraph_format.space_before = Pt(STYLE["spacing_before_h1_pt"])
        heading.paragraph_format.space_after = Pt(STYLE["spacing_after_h1_pt"])
    elif level == 2:
        heading.paragraph_format.space_before = Pt(STYLE["spacing_before_h2_pt"])
        heading.paragraph_format.space_after = Pt(STYLE["spacing_after_h2_pt"])

    for run in heading.runs:
        run.font.name = STYLE["font_heading"]
        run.font.bold = True
        if level == 1:
            run.font.size = Pt(STYLE["font_size_h1"])
            run.font.color.rgb = STYLE["color_h1"]
        elif level == 2:
            run.font.size = Pt(STYLE["font_size_h2"])
            run.font.color.rgb = STYLE["color_h2"]
        else:
            run.font.size = Pt(STYLE["font_size_h3"])
            run.font.color.rgb = STYLE["color_h3"]


# =============================================================================
# PARAGRAPH STYLING (§8.1)
# =============================================================================

def _style_paragraph(para, para_type: str = "narrative") -> None:
    """Apply paragraph styling per §8.1."""
    para.paragraph_format.space_after = Pt(STYLE["spacing_after_body_pt"])
    para.paragraph_format.line_spacing = STYLE["line_spacing"]
    para.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    for run in para.runs:
        run.font.name = STYLE["font_body"]
        run.font.size = Pt(STYLE["font_size_body"])
        if para_type == "footnote":
            run.font.size = Pt(STYLE["font_size_footnote"])
            run.font.italic = True
            run.font.color.rgb = RGBColor(0x64, 0x64, 0x64)
        elif para_type == "methodology":
            run.font.italic = True
        elif para_type == "forward_looking":
            run.font.italic = True
            run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)


# =============================================================================
# TABLE (REQ-ASSY-03: Custom ESG table, REQ-ASSY-05: numeric formatting)
# =============================================================================

def _add_esg_table(doc: Document, table_data: dict[str, Any]) -> None:
    """Add ESG-styled table with navy header and alternating rows.

    Args:
        doc: Document instance.
        table_data: Dict with caption, headers, rows, source_note.
    """
    caption = table_data.get("caption", "")
    headers = table_data.get("headers", [])
    rows = table_data.get("rows", [])
    source_note = table_data.get("source_note", "")

    if not headers:
        return

    if caption:
        cap_p = doc.add_paragraph()
        run = cap_p.add_run(caption)
        run.font.bold = True
        run.font.size = Pt(10)
        run.font.name = STYLE["font_body"]

    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # REQ-ASSY-03: Navy header row
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = str(header)
        # Header background color
        tc = cell._tc
        tcPr = tc.get_or_add_tcPr()
        shading = OxmlElement("w:shd")
        shading.set(qn("w:fill"), "1B3A6B")
        shading.set(qn("w:val"), "clear")
        tcPr.append(shading)
        for run in cell.paragraphs[0].runs:
            run.font.bold = True
            run.font.size = Pt(STYLE["font_size_table"])
            run.font.name = STYLE["font_body"]
            run.font.color.rgb = STYLE["color_table_header_text"]

    # Data rows with alternating colors
    for row_idx, row_data in enumerate(rows):
        for col_idx, cell_value in enumerate(row_data):
            if col_idx >= len(headers):
                break
            cell = table.rows[row_idx + 1].cells[col_idx]

            # REQ-ASSY-05: Numeric right-alignment + formatting
            str_val = str(cell_value) if cell_value is not None else ""
            cell.text = str_val
            para = cell.paragraphs[0]

            # Right-align numeric values
            if _is_numeric(str_val):
                para.alignment = WD_ALIGN_PARAGRAPH.RIGHT

            for run in para.runs:
                run.font.size = Pt(STYLE["font_size_table"])
                run.font.name = STYLE["font_body"]

            # Alternating row background (REQ-ASSY-03)
            if row_idx % 2 == 1:
                tc = cell._tc
                tcPr = tc.get_or_add_tcPr()
                shading = OxmlElement("w:shd")
                shading.set(qn("w:fill"), "F2F6FC")
                shading.set(qn("w:val"), "clear")
                tcPr.append(shading)

    if source_note:
        note_p = doc.add_paragraph()
        run = note_p.add_run(f"Source: {source_note}")
        run.font.size = Pt(8)
        run.font.italic = True
        run.font.name = STYLE["font_body"]

    doc.add_paragraph()


# =============================================================================
# APPENDICES (REQ-ASSY-13)
# =============================================================================

def _add_appendices(doc: Document, sections: list[dict], framework: str) -> None:
    """Add appendix sections: Methodology, GRI Content Index, Data Quality.

    Args:
        doc: Document instance.
        sections: All assembled sections (for extracting metadata).
        framework: Report framework.
    """
    doc.add_page_break()

    # Appendix A: Methodology Notes
    h = doc.add_heading("Appendix A: Methodology Notes", level=1)
    _style_heading(h, level=1)
    p = doc.add_paragraph(
        "This report applies the GHG Protocol Corporate Accounting and Reporting Standard "
        "(Revised 2015) for Scope 1 and 2 emissions, and the PCAF Global GHG Accounting "
        "and Reporting Standard Part A (2022) for Scope 3 Category 15 financed emissions. "
        "GWP values from IPCC AR6 (GWP100): CH4 = 29.8, N2O = 273.0."
    )
    _style_paragraph(p, "narrative")

    # Appendix B: Data Quality Summary
    h2 = doc.add_heading("Appendix B: Data Quality Summary", level=1)
    _style_heading(h2, level=1)
    p2 = doc.add_paragraph(
        "Data quality is assessed per the PCAF data quality scoring framework (1-5) "
        "and the GHG Protocol data quality indicators. Portfolio-weighted PCAF score "
        "and data completeness percentage are reported in the main body."
    )
    _style_paragraph(p2, "narrative")

    # Appendix C: GRI Content Index (for GRI framework)
    if framework in ("GRI_305", "MULTI_FRAMEWORK"):
        h3 = doc.add_heading("Appendix C: GRI Content Index", level=1)
        _style_heading(h3, level=1)
        _add_esg_table(doc, {
            "caption": "GRI Standards Content Index",
            "headers": ["GRI Standard", "Disclosure", "Section Reference", "Omission"],
            "rows": [
                ["GRI 305-1", "Direct (Scope 1) GHG emissions", "Section: Scope 1", "None"],
                ["GRI 305-2", "Energy indirect (Scope 2) GHG emissions", "Section: Scope 2", "None"],
                ["GRI 305-3", "Other indirect (Scope 3) GHG emissions", "Section: PCAF", "None"],
                ["GRI 305-4", "GHG emissions intensity", "Section: Intensity", "None"],
                ["GRI 305-5", "Reduction of GHG emissions", "Section: Reduction", "Partial — targets in development"],
            ],
            "source_note": "GRI Standards 2021"
        })


# =============================================================================
# UTILITIES
# =============================================================================

def _add_horizontal_rule(doc: Document) -> None:
    """Add a horizontal rule (paragraph border bottom)."""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "999999")
    pBdr.append(bottom)
    pPr.append(pBdr)


def _add_page_number_field(paragraph) -> None:
    """Add auto 'Page X of Y' field."""
    run = paragraph.add_run("Page ")
    run.font.size = Pt(STYLE["font_size_header_footer"])
    run.font.color.rgb = STYLE["color_footer"]

    fld1 = OxmlElement("w:fldChar")
    fld1.set(qn("w:fldCharType"), "begin")
    instr1 = OxmlElement("w:instrText")
    instr1.set(qn("xml:space"), "preserve")
    instr1.text = " PAGE "
    fld2 = OxmlElement("w:fldChar")
    fld2.set(qn("w:fldCharType"), "end")

    run2 = paragraph.add_run()
    run2._r.append(fld1)
    run2._r.append(instr1)
    run2._r.append(fld2)
    run2.font.size = Pt(STYLE["font_size_header_footer"])
    run2.font.color.rgb = STYLE["color_footer"]

    run3 = paragraph.add_run(" of ")
    run3.font.size = Pt(STYLE["font_size_header_footer"])
    run3.font.color.rgb = STYLE["color_footer"]

    fld3 = OxmlElement("w:fldChar")
    fld3.set(qn("w:fldCharType"), "begin")
    instr2 = OxmlElement("w:instrText")
    instr2.set(qn("xml:space"), "preserve")
    instr2.text = " NUMPAGES "
    fld4 = OxmlElement("w:fldChar")
    fld4.set(qn("w:fldCharType"), "end")

    run4 = paragraph.add_run()
    run4._r.append(fld3)
    run4._r.append(instr2)
    run4._r.append(fld4)
    run4.font.size = Pt(STYLE["font_size_header_footer"])
    run4.font.color.rgb = STYLE["color_footer"]


def _is_numeric(val: str) -> bool:
    """Check if string value is numeric (for right-alignment)."""
    try:
        float(val.replace(",", "").replace("%", ""))
        return True
    except (ValueError, AttributeError):
        return False


def _extract_section_type(section_id: str) -> str:
    """Extract section type from section_id for ordering."""
    sid = section_id.lower()
    if "scope1" in sid or "_s1_" in sid:
        return "scope1"
    if "scope2" in sid or "_s2_" in sid:
        return "scope2"
    if "pcaf" in sid or "scope3" in sid or "_s3_" in sid:
        return "scope3_pcaf"
    if "intensity" in sid:
        return "intensity"
    if "summary" in sid:
        return "summary"
    if "gov" in sid:
        return "governance"
    return "unknown"
