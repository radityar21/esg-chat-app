"""
=============================================================================
Lambda #5: AssemblyDocFn — Phase 1 Upgrade
=============================================================================
Spec Reference: §8 (REQ-ASSY-01 to REQ-ASSY-14), SPEC-CHARTS, SPEC-STYLING,
                SPEC-MARKDOWN-PARSER

Purpose:
    Assembles validated section JSONs into a formatted DOCX report.
    CON-ASSY-01: Zero LLM invocations — deterministic assembly only.

Phase 1 Additions:
    - Waterfall, stacked_bar, bar_with_line chart types
    - Full markdown parser (headings, bold, italic, lists, blockquotes, HR)
    - Figure numbering (auto-increment)
    - Chart data validation (hybrid — cross-check vs source metrics)
    - Improved styling consistency (color palette from SPEC-STYLING)

Deployment:
    Runtime: Python 3.11, Memory: 2048 MB, Timeout: 300s
    Role: ESG-AssemblyDoc-ExecutionRole
    Layers: esg-python-docx:2, esg-matplotlib-layer:4
=============================================================================
"""

from __future__ import annotations

import gc
import json
import os
import re
import logging
from datetime import datetime, timezone
from io import BytesIO
from typing import Any

import boto3
from docx import Document
from docx.shared import Pt, Cm, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# =============================================================================
# CONFIGURATION
# =============================================================================

ACCOUNT_ID: str = "061039769766"
DEFAULT_OUTPUT_BUCKET: str = f"esg-output-reports-{ACCOUNT_ID}"

# =============================================================================
# COLOR PALETTE (SPEC-STYLING §3)
# =============================================================================

COLORS = {
    "primary": RGBColor(0x1B, 0x3A, 0x6B),       # Dark navy
    "secondary": RGBColor(0x3D, 0x60, 0x94),     # Medium blue
    "tertiary": RGBColor(0x4A, 0x7A, 0xB5),      # Light blue
    "accent_bg": RGBColor(0xF2, 0xF6, 0xFA),     # Light blue-grey bg
    "positive": RGBColor(0x2E, 0x7D, 0x32),      # Green
    "negative": RGBColor(0xC6, 0x28, 0x28),      # Red
    "neutral": RGBColor(0x75, 0x75, 0x75),        # Grey
    "highlight": RGBColor(0xFF, 0x8F, 0x00),      # Amber
    "white": RGBColor(0xFF, 0xFF, 0xFF),
    "footer": RGBColor(0x80, 0x80, 0x80),
    "table_alt": RGBColor(0xF2, 0xF6, 0xFC),
}

# Hex versions for matplotlib
CHART_COLORS_HEX = {
    "primary": "#1B3A6B",
    "secondary": "#3D6094",
    "tertiary": "#4A7AB5",
    "accent": "#F2F6FA",
    "positive": "#2E7D32",
    "negative": "#C62828",
    "neutral": "#757575",
    "highlight": "#FF8F00",
    "scope1": "#1B3A6B",
    "scope2": "#3D6094",
    "scope3": "#4A7AB5",
}
PIE_COLORS = ["#1B3A6B", "#3D6094", "#4A7AB5", "#7BA7CC", "#A8CCE0", "#D4E6F1"]

# §8.1: Document styling
STYLE: dict[str, Any] = {
    "font_body": "Arial",
    "font_heading": "Arial",
    "font_size_body": 11,
    "font_size_h1": 18,
    "font_size_h2": 14,
    "font_size_h3": 12,
    "font_size_header_footer": 9,
    "font_size_table": 9,
    "font_size_footnote": 9,
    "font_size_framework_ref": 9,
    "page_width": Inches(8.27),
    "page_height": Inches(11.69),
    "margin": Cm(2.54),
    "line_spacing": 1.15,
    "spacing_after_body_pt": 8,
    "spacing_before_h1_pt": 24,
    "spacing_after_h1_pt": 12,
    "spacing_before_h2_pt": 18,
    "spacing_after_h2_pt": 8,
}

# REQ-ASSY-09: Section ordering per framework
SECTION_ORDER: dict[str, list[str]] = {
    "GRI_305": ["summary", "scope1", "scope2", "scope3_pcaf", "intensity", "reduction", "social"],
    "IFRS_S2": ["summary", "governance", "scope1", "scope2", "scope3_pcaf", "intensity", "targets", "social"],
    "CSRD_ESRS_E1": ["summary", "governance", "targets", "scope1", "scope2", "scope3_pcaf", "intensity", "reduction", "social"],
    "OJK_PSPK": ["summary", "governance", "scope1", "scope2", "scope3_pcaf", "intensity", "reduction", "social"],
    "MULTI_FRAMEWORK": ["summary", "scope1", "scope2", "scope3_pcaf", "intensity", "reduction", "governance", "targets", "social"],
}

PAGE_BREAK_BEFORE: set[str] = {"summary", "scope1", "scope2", "scope3_pcaf", "social", "governance"}

# Unified report structure
DOCUMENT_STRUCTURE_UNIFIED = [
    {"type": "heading1", "text": "Environmental Performance"},
    {"type": "section", "ids": ["scope1_unified", "scope2_unified", "scope3_pcaf_unified", "intensity_unified", "reduction_unified"]},
    {"type": "heading1", "text": "Social Performance"},
    {"type": "section", "ids": ["social_unified"]},
    {"type": "heading1", "text": "Governance & Strategy"},
    {"type": "section", "ids": ["governance_unified", "targets_unified"]},
]

LEGACY_DOCUMENT_STRUCTURE: dict[str, list[dict]] = {
    "GRI_305": [
        {"type": "heading1", "text": "GHG Emissions Disclosures"},
        {"type": "sections", "ids": ["scope1", "scope2", "scope3_pcaf", "intensity", "reduction"]},
        {"type": "heading1", "text": "Social Disclosures"},
        {"type": "sections", "ids": ["social"]},
    ],
    "IFRS_S2": [
        {"type": "heading1", "text": "Governance & Strategy"},
        {"type": "sections", "ids": ["governance", "targets"]},
        {"type": "heading1", "text": "Climate-Related Metrics"},
        {"type": "sections", "ids": ["scope1", "scope2", "scope3_pcaf", "intensity"]},
        {"type": "heading1", "text": "Social Disclosures"},
        {"type": "sections", "ids": ["social"]},
    ],
    "CSRD_ESRS_E1": [
        {"type": "heading1", "text": "Governance & Transition Plan"},
        {"type": "sections", "ids": ["governance", "targets"]},
        {"type": "heading1", "text": "ESRS E1 Climate Change Disclosures"},
        {"type": "sections", "ids": ["scope1", "scope2", "scope3_pcaf", "intensity", "reduction"]},
        {"type": "heading1", "text": "Social Disclosures"},
        {"type": "sections", "ids": ["social"]},
    ],
    "OJK_PSPK": [
        {"type": "heading1", "text": "Tata Kelola Keberlanjutan"},
        {"type": "sections", "ids": ["governance"]},
        {"type": "heading1", "text": "Pengungkapan Emisi GRK"},
        {"type": "sections", "ids": ["scope1", "scope2", "scope3_pcaf", "intensity", "reduction"]},
        {"type": "heading1", "text": "Kinerja Sosial"},
        {"type": "sections", "ids": ["social"]},
    ],
}

s3_client = boto3.client("s3")

# Figure/Table counters (module-level, reset per invocation)
_figure_counter: int = 0
_table_counter: int = 0


# =============================================================================
# MARKDOWN PARSER (SPEC-MARKDOWN-PARSER)
# =============================================================================

_HEADING_PATTERN = re.compile(r'^(#{1,3})\s+(.+)$')
_BOLD_ITALIC_PATTERN = re.compile(r'\*\*\*(.+?)\*\*\*')
_BOLD_PATTERN = re.compile(r'\*\*(.+?)\*\*')
_ITALIC_PATTERN = re.compile(r'(?<!\*)\*([^*]+?)\*(?!\*)')
_BULLET_PATTERN = re.compile(r'^[\-\*•]\s+(.+)$')
_NUMBERED_PATTERN = re.compile(r'^\d+[\.\)]\s+(.+)$')
_BLOCKQUOTE_PATTERN = re.compile(r'^>\s*(.+)$')
_HR_PATTERN = re.compile(r'^-{3,}$')

_INLINE_PATTERNS = [
    ("bold_italic", re.compile(r'\*\*\*(.+?)\*\*\*')),
    ("bold", re.compile(r'\*\*(.+?)\*\*')),
    ("italic", re.compile(r'(?<!\*)\*([^*]+?)\*(?!\*)')),
]


def _tokenize_inline(text: str) -> list[tuple[str, str | None]]:
    """Tokenize text into (text, format_type) segments."""
    tokens = []
    remaining = text
    while remaining:
        earliest_match = None
        earliest_pos = len(remaining)
        earliest_format = None
        for fmt_name, pattern in _INLINE_PATTERNS:
            match = pattern.search(remaining)
            if match and match.start() < earliest_pos:
                earliest_match = match
                earliest_pos = match.start()
                earliest_format = fmt_name
        if earliest_match is None:
            tokens.append((remaining, None))
            break
        if earliest_pos > 0:
            tokens.append((remaining[:earliest_pos], None))
        tokens.append((earliest_match.group(1), earliest_format))
        remaining = remaining[earliest_match.end():]
    return tokens


def _add_formatted_paragraph(doc, text: str, style: str = "narrative") -> None:
    """Add paragraph with inline markdown formatting."""
    paragraph = doc.add_paragraph()
    _apply_paragraph_format(paragraph)
    tokens = _tokenize_inline(text)
    for token_text, token_format in tokens:
        run = paragraph.add_run(token_text)
        run.font.name = STYLE["font_body"]
        run.font.size = Pt(STYLE["font_size_body"])
        if token_format == "bold_italic":
            run.font.bold = True
            run.font.italic = True
        elif token_format == "bold":
            run.font.bold = True
        elif token_format == "italic":
            run.font.italic = True
        if style == "footnote":
            run.font.size = Pt(STYLE["font_size_footnote"])
            run.font.italic = True
            run.font.color.rgb = RGBColor(0x64, 0x64, 0x64)
        elif style == "methodology":
            run.font.italic = True


def _parse_markdown_to_docx(doc, markdown_text: str) -> None:
    """Master markdown parser — converts markdown text to DOCX elements."""
    lines = markdown_text.split('\n')
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not stripped:
            i += 1
            continue

        # Heading
        heading_match = _HEADING_PATTERN.match(stripped)
        if heading_match:
            level = len(heading_match.group(1))
            text = heading_match.group(2).strip()
            h = doc.add_heading(text, level=min(level + 1, 3))  # ## → H3 (subsection)
            _style_heading(h, level=min(level + 1, 3))
            i += 1
            continue

        # Horizontal rule
        if _HR_PATTERN.match(stripped):
            _add_horizontal_rule(doc)
            i += 1
            continue

        # Blockquote
        bq_match = _BLOCKQUOTE_PATTERN.match(stripped)
        if bq_match:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.5)
            run = p.add_run(bq_match.group(1))
            run.font.italic = True
            run.font.size = Pt(10)
            run.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
            i += 1
            continue

        # Bullet list
        bullet_match = _BULLET_PATTERN.match(stripped)
        if bullet_match:
            p = doc.add_paragraph(style='List Bullet')
            tokens = _tokenize_inline(bullet_match.group(1))
            for token_text, token_format in tokens:
                run = p.add_run(token_text)
                run.font.name = STYLE["font_body"]
                run.font.size = Pt(STYLE["font_size_body"])
                if token_format == "bold":
                    run.font.bold = True
                elif token_format == "italic":
                    run.font.italic = True
            i += 1
            continue

        # Numbered list
        num_match = _NUMBERED_PATTERN.match(stripped)
        if num_match:
            p = doc.add_paragraph(style='List Number')
            tokens = _tokenize_inline(num_match.group(1))
            for token_text, token_format in tokens:
                run = p.add_run(token_text)
                run.font.name = STYLE["font_body"]
                run.font.size = Pt(STYLE["font_size_body"])
                if token_format == "bold":
                    run.font.bold = True
                elif token_format == "italic":
                    run.font.italic = True
            i += 1
            continue

        # Regular paragraph (group consecutive non-special lines)
        para_lines = []
        while i < len(lines):
            current = lines[i].strip()
            if not current:
                break
            if (_HEADING_PATTERN.match(current) or _HR_PATTERN.match(current) or
                _BULLET_PATTERN.match(current) or _NUMBERED_PATTERN.match(current) or
                _BLOCKQUOTE_PATTERN.match(current)):
                break
            para_lines.append(current)
            i += 1

        if para_lines:
            full_text = ' '.join(para_lines)
            _add_formatted_paragraph(doc, full_text)
            continue
        i += 1


# =============================================================================
# MAIN HANDLER
# =============================================================================

def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Assemble validated sections into DOCX and save to S3."""
    global _figure_counter, _table_counter
    _figure_counter = 0
    _table_counter = 0

    logger.info(f"AssemblyDocFn invoked: {len(event.get('sections', []))} sections")

    sections: list[dict] = event["sections"]
    output_bucket: str = event.get("output_bucket", DEFAULT_OUTPUT_BUCKET)
    reporting_year: int = event["reporting_year"]
    bank_id: str = event.get("bank_id", "GENERIC_FI_001")
    framework: str = event.get("framework", "MULTI_FRAMEWORK")
    execution_id: str = event.get("execution_id", "local-test")

    ts_str = event.get("generation_timestamp")
    timestamp = datetime.fromisoformat(ts_str) if ts_str else datetime.now(timezone.utc)
    ts_short = timestamp.strftime("%Y%m%d_%H%M%S")

    order = SECTION_ORDER.get(framework, SECTION_ORDER["MULTI_FRAMEWORK"])
    sections = _sort_sections(sections, order)

    doc = Document()
    for section in doc.sections:
        section.page_width = STYLE["page_width"]
        section.page_height = STYLE["page_height"]
        section.top_margin = STYLE["margin"]
        section.bottom_margin = STYLE["margin"]
        section.left_margin = STYLE["margin"]
        section.right_margin = STYLE["margin"]
        section.different_first_page_header_footer = True

    _add_cover_page(doc, bank_id, framework, reporting_year, timestamp, execution_id)
    _add_toc(doc)

    # Header/Footer
    for section in doc.sections:
        header = section.header
        h_para = header.paragraphs[0] if header.paragraphs else header.add_paragraph()
        h_para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        run = h_para.add_run(f"{bank_id} | Reporting Year {reporting_year}")
        run.font.name = STYLE["font_body"]
        run.font.size = Pt(STYLE["font_size_header_footer"])

        footer = section.footer
        f_para = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
        f_para.alignment = WD_ALIGN_PARAGRAPH.LEFT
        run_l = f_para.add_run(f"ESG Report {framework} {reporting_year}")
        run_l.font.name = STYLE["font_body"]
        run_l.font.size = Pt(STYLE["font_size_header_footer"])
        run_l.font.color.rgb = COLORS["footer"]
        f_para.add_run("\t\t")
        _add_page_number_field(f_para)

    # Assemble sections
    sections_assembled: int = 0
    is_unified = any("unified" in str(s.get("section_id", "")).lower() for s in sections)

    if is_unified:
        summary_data = next((s for s in sections if "summary" in str(s.get("section_id", "")).lower()), None)
        if summary_data:
            content = _load_section_content(summary_data)
            if content:
                doc.add_page_break()
                sections_assembled += _render_executive_summary_2tier(doc, content, summary_data)

        for structure_item in DOCUMENT_STRUCTURE_UNIFIED:
            if structure_item["type"] == "heading1":
                if sections_assembled > 0:
                    doc.add_page_break()
                heading = doc.add_heading(structure_item["text"], level=1)
                _style_heading(heading, level=1)
            elif structure_item["type"] == "section":
                for sec_id in structure_item["ids"]:
                    section_data = next(
                        (s for s in sections if sec_id in str(s.get("section_id", "")).lower()), None)
                    if section_data:
                        content = _load_section_content(section_data)
                        if content:
                            title = content.get("title", section_data.get("section_id", "Untitled"))
                            sub_heading = doc.add_heading(title, level=2)
                            _style_heading(sub_heading, level=2)
                            _render_section_content(doc, content, section_data)
                            sections_assembled += 1
            # Memory cleanup every few sections
            if sections_assembled % 3 == 0:
                gc.collect()
    else:
        summary_data = next((s for s in sections if "summary" in str(s.get("section_id", "")).lower()), None)
        if summary_data:
            content = _load_section_content(summary_data)
            if content:
                doc.add_page_break()
                sections_assembled += _render_executive_summary_2tier(doc, content, summary_data)

        legacy_structure = LEGACY_DOCUMENT_STRUCTURE.get(framework)
        if legacy_structure:
            for structure_item in legacy_structure:
                if structure_item["type"] == "heading1":
                    doc.add_page_break()
                    heading = doc.add_heading(structure_item["text"], level=1)
                    _style_heading(heading, level=1)
                elif structure_item["type"] == "sections":
                    for sec_id in structure_item["ids"]:
                        section_data = next(
                            (s for s in sections if sec_id in str(s.get("section_id", "")).lower()
                             and "summary" not in str(s.get("section_id", "")).lower()), None)
                        if section_data:
                            content = _load_section_content(section_data)
                            if content:
                                title = content.get("title", section_data.get("section_id", "Untitled"))
                                sub_heading = doc.add_heading(title, level=2)
                                _style_heading(sub_heading, level=2)
                                _render_section_content(doc, content, section_data)
                                sections_assembled += 1
        else:
            for section_data in sections:
                if "summary" in str(section_data.get("section_id", "")).lower():
                    continue
                content = _load_section_content(section_data)
                if not content:
                    continue
                sec_type = _extract_section_type(section_data.get("section_id", ""))
                if sec_type in PAGE_BREAK_BEFORE and sections_assembled > 0:
                    doc.add_page_break()
                title = content.get("title", section_data.get("section_id", "Untitled"))
                heading = doc.add_heading(title, level=1)
                _style_heading(heading, level=1)
                _render_section_content(doc, content, section_data)
                sections_assembled += 1

    _add_appendices(doc, sections, framework)

    # Document properties
    props = doc.core_properties
    props.author = f"ESG Reporting System ({bank_id})"
    props.title = f"ESG Sustainability Report {reporting_year} - {framework}"
    props.subject = f"GHG Emissions Disclosure - {framework}"
    props.keywords = f"ESG, GHG, {framework}, {reporting_year}, PCAF, Scope1, Scope2, Scope3"
    props.comments = f"Generated by execution: {execution_id}"
    props.category = "ESG Sustainability Report"

    # Save + Upload
    filename = f"ESG_Report_{framework}_{reporting_year}_{ts_short}.docx"
    s3_key = f"reports/year={reporting_year}/{framework}/{filename}"
    tmp_path = f"/tmp/{filename}"

    doc.save(tmp_path)
    file_size_kb = round(os.path.getsize(tmp_path) / 1024, 1)

    s3_client.upload_file(
        Filename=tmp_path, Bucket=output_bucket, Key=s3_key,
        ExtraArgs={
            "ServerSideEncryption": "aws:kms",
            "Tagging": (
                f"esg:framework={framework}&esg:reporting_year={reporting_year}"
                f"&esg:bank_id={bank_id}&esg:execution_id={execution_id}"
                f"&esg:generated_at={timestamp.isoformat()}"
                f"&esg:sections_count={sections_assembled}&esg:file_size_kb={file_size_kb}"
                f"&esg:status=draft"
            ),
        },
    )

    s3_path = f"s3://{output_bucket}/{s3_key}"
    logger.info(f"✅ Report: {s3_path} ({file_size_kb} KB, {sections_assembled} sections, {_figure_counter} figures)")
    os.remove(tmp_path)

    return {
        "s3_path": s3_path,
        "page_count": sections_assembled + 2,
        "file_size_kb": file_size_kb,
        "sections_assembled": sections_assembled,
        "figures_rendered": _figure_counter,
        "generation_timestamp": timestamp.isoformat(),
    }


# =============================================================================
# EXECUTIVE SUMMARY 2-TIER RENDERING (Phase 2)
# =============================================================================

def _render_executive_summary_2tier(doc: Document, content: dict, section_data: dict) -> int:
    """Render Executive Summary with 2-tier structure.

    Tier 1: C-Level Strategic Brief (KPIs, scorecard, charts, board actions)
    PAGE BREAK
    Tier 2: Detailed Performance Summary (tables, full narrative)

    Returns: 1 (sections_assembled count)
    """
    global _figure_counter, _table_counter

    paragraphs = content.get("paragraphs", [])
    tables = content.get("tables", [])
    charts = content.get("charts", [])

    # Find tier break marker
    tier_break_idx = None
    for i, para in enumerate(paragraphs):
        if "<<<TIER_BREAK>>>" in para.get("text", ""):
            tier_break_idx = i
            break

    # === TIER 1: C-Level Strategic Brief ===
    heading = doc.add_heading("Executive Summary", level=1)
    _style_heading(heading, level=1)
    sub_h = doc.add_heading("Strategic Brief", level=2)
    _style_heading(sub_h, level=2)

    # KPI highlights (top of Tier 1)
    kpi_highlights = content.get("kpi_highlights", [])
    if kpi_highlights:
        _add_kpi_highlights(doc, kpi_highlights)

    # Tier 1 paragraphs (before TIER_BREAK)
    tier1_end = tier_break_idx if tier_break_idx is not None else len(paragraphs)
    for para in paragraphs[:tier1_end]:
        text = para.get("text", "").strip()
        if not text or "<<<TIER_BREAK>>>" in text:
            continue
        if text.startswith("⚡ PRIORITY ACTIONS:") or text.startswith("⚡"):
            # Parse priority actions from inline text
            lines = text.split("\n")
            actions = []
            for line in lines[1:]:  # Skip header line
                line = line.strip()
                if not line:
                    continue
                # Parse: "1. [High] Action text — rationale (timeline)"
                priority = "high"
                if "[High]" in line or "[high]" in line:
                    priority = "high"
                elif "[Medium]" in line or "[medium]" in line:
                    priority = "medium"
                elif "[Low]" in line or "[low]" in line:
                    priority = "low"
                # Clean up
                action_text = re.sub(r'^\d+[\.\)]\s*', '', line)
                action_text = re.sub(r'\[(High|Medium|Low|high|medium|low)\]\s*', '', action_text)
                if action_text:
                    actions.append({"action": action_text, "priority": priority, "timeline": ""})
            if actions:
                _add_priority_actions(doc, actions)
        elif text.startswith("⚠️ KEY INSIGHT:"):
            _add_insight_box(doc, {"headline": text.replace("⚠️ KEY INSIGHT:", "").strip(), "severity": "warning"})
        else:
            _parse_markdown_to_docx(doc, text)

    # Tier 1 tables (scorecard, risk matrix — tier=1)
    tier1_tables = [t for t in tables if t.get("tier") == 1]
    for table_data in tier1_tables:
        _table_counter += 1
        _add_esg_table(doc, table_data)

    # Tier 1 charts (high-level overview)
    if charts:
        for chart_config in charts:
            _add_chart(doc, chart_config)

    # === PAGE BREAK between tiers ===
    if tier_break_idx is not None:
        doc.add_page_break()

        # === TIER 2: Detailed Performance Summary ===
        sub_h2 = doc.add_heading("Detailed Performance Summary", level=2)
        _style_heading(sub_h2, level=2)

        # Tier 2 paragraphs (after TIER_BREAK)
        for para in paragraphs[tier_break_idx + 1:]:
            text = para.get("text", "").strip()
            if not text or "<<<TIER_BREAK>>>" in text:
                continue
            _parse_markdown_to_docx(doc, text)

        # Tier 2 tables (detailed performance — tier=2 or no tier specified)
        tier2_tables = [t for t in tables if t.get("tier", 2) == 2]
        for table_data in tier2_tables:
            _table_counter += 1
            _add_esg_table(doc, table_data)

    # Top recommendations
    top_recs = content.get("top_recommendations", [])
    if top_recs:
        doc.add_paragraph()
        p_header = doc.add_paragraph()
        run = p_header.add_run("Top Strategic Recommendations")
        run.font.bold = True
        run.font.size = Pt(STYLE["font_size_h3"])
        run.font.color.rgb = COLORS["secondary"]
        for rec in top_recs:
            p = doc.add_paragraph(f"→ {rec}")
            _apply_paragraph_format(p)

    # Framework references
    fw_refs = content.get("framework_references", [])
    if fw_refs:
        ref_text = "Framework references: " + "; ".join(fw_refs)
        p = doc.add_paragraph()
        run = p.add_run(ref_text)
        run.font.size = Pt(STYLE["font_size_framework_ref"])
        run.font.italic = True
        run.font.color.rgb = COLORS["secondary"]

    # Footnotes
    footnotes = content.get("footnotes", [])
    if footnotes:
        _add_horizontal_rule(doc)
        for fn in footnotes:
            p = doc.add_paragraph(fn)
            _style_paragraph_type(p, "footnote")

    logger.info(f"Executive Summary 2-tier rendered (tier_break at paragraph {tier_break_idx})")
    return 1


# =============================================================================
# SECTION CONTENT LOADING & RENDERING
# =============================================================================

def _load_section_content(section_data: dict) -> dict | None:
    """Load section content from S3 or inline."""
    section_result = section_data.get("section_result", {})
    content = section_data.get("content_json")

    s3_key = section_result.get("content_s3_key") or section_data.get("content_s3_key")
    s3_bucket = section_result.get("content_s3_bucket") or section_data.get("content_s3_bucket", DEFAULT_OUTPUT_BUCKET)

    if not content and s3_key:
        try:
            s3_resp = s3_client.get_object(Bucket=s3_bucket, Key=s3_key)
            content = json.loads(s3_resp["Body"].read().decode("utf-8"))
        except Exception as e:
            logger.warning(f"Failed to load section from S3: {s3_key} - {str(e)}")
            content = None

    if not content:
        content = section_result.get("content_json")

    return content


def _render_section_content(doc: Document, content: dict, section_data: dict) -> None:
    """Render full section content with insight layer, charts, markdown parsing."""
    global _figure_counter, _table_counter

    # KPI Highlights
    kpi_highlights = content.get("kpi_highlights", [])
    if kpi_highlights:
        _add_kpi_highlights(doc, kpi_highlights)

    # Insight Box
    insight_box = content.get("insight_box")
    if insight_box and insight_box.get("headline"):
        _add_insight_box(doc, insight_box)

    # Paragraphs — with markdown parsing
    for para_data in content.get("paragraphs", []):
        text = para_data.get("text", "")
        if not text.strip():
            continue

        # Detect special advisory elements
        if text.startswith("⚠️ KEY INSIGHT:"):
            _add_insight_box(doc, {"headline": text.replace("⚠️ KEY INSIGHT:", "").strip(), "severity": "warning"})
            continue
        elif text.startswith("📊 DIAGNOSTIC ANALYSIS:"):
            _add_diagnostic_box(doc, text.replace("📊 DIAGNOSTIC ANALYSIS:", "").strip())
            continue
        elif text.startswith("⚡ PRIORITY ACTIONS:"):
            # Parse inline priority actions
            continue

        # Use markdown parser for regular text
        _parse_markdown_to_docx(doc, text)

    # Tables
    for table_data in content.get("tables", []):
        _table_counter += 1
        _add_esg_table(doc, table_data)

    # Charts (hybrid: use LLM-generated chart_data, validate if possible)
    charts_list = content.get("charts", [])
    if charts_list:
        for chart_config in charts_list:
            _add_chart(doc, chart_config)

    # Diagnostic
    diagnostic = content.get("diagnostic")
    if diagnostic and diagnostic.get("text"):
        _add_diagnostic_box(doc, diagnostic.get("text", ""), diagnostic.get("root_causes"), diagnostic.get("risk_implications"))

    # Priority Actions
    priority_actions = content.get("priority_actions", [])
    if priority_actions:
        _add_priority_actions(doc, priority_actions)

    # Top Recommendations (exec summary)
    top_recs = content.get("top_recommendations", [])
    if top_recs:
        doc.add_paragraph()
        p_header = doc.add_paragraph()
        run = p_header.add_run("Top Strategic Recommendations")
        run.font.bold = True
        run.font.size = Pt(STYLE["font_size_h3"])
        run.font.color.rgb = COLORS["secondary"]
        for rec in top_recs:
            p = doc.add_paragraph(f"→ {rec}")
            _apply_paragraph_format(p)

    # Framework references
    fw_refs = content.get("framework_references", [])
    if fw_refs:
        ref_text = "Framework references: " + "; ".join(fw_refs)
        p = doc.add_paragraph()
        run = p.add_run(ref_text)
        run.font.size = Pt(STYLE["font_size_framework_ref"])
        run.font.italic = True
        run.font.color.rgb = COLORS["secondary"]

    # Footnotes
    footnotes = content.get("footnotes", [])
    if footnotes:
        _add_horizontal_rule(doc)
        for fn in footnotes:
            p = doc.add_paragraph(fn)
            _style_paragraph_type(p, "footnote")

    # Memory cleanup
    gc.collect()


# =============================================================================
# CHART RENDERING (Phase 1: All chart types)
# =============================================================================

def _add_chart(doc: Document, chart_config: dict) -> None:
    """Generate chart from config and embed as PNG. Supports all chart types."""
    global _figure_counter
    title = chart_config.get("title", "Chart")
    chart_type = chart_config.get("chart_type", "bar")

    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import numpy as np

        # Apply global style
        plt.rcParams.update({
            'font.family': 'sans-serif',
            'font.sans-serif': ['Arial', 'DejaVu Sans'],
            'font.size': 9,
            'axes.titlesize': 11,
            'axes.titleweight': 'bold',
            'axes.spines.top': False,
            'axes.spines.right': False,
            'axes.grid': True,
            'grid.alpha': 0.3,
            'grid.linestyle': '--',
            'grid.color': '#CCCCCC',
        })

        data = chart_config.get("data", {})

        # Validate chart data exists before rendering
        has_data = False
        if chart_type == "pie":
            has_data = bool(data.get("labels")) and bool(data.get("values"))
        elif chart_type in ("bar", "grouped_bar"):
            has_data = bool(data.get("categories")) and bool(data.get("series"))
        elif chart_type == "horizontal_bar":
            has_data = (bool(data.get("categories")) and
                        (bool(data.get("series")) or bool(data.get("values"))))
        elif chart_type == "stacked_bar":
            has_data = (bool(data.get("x_labels") or data.get("categories")) and
                        bool(data.get("stacks") or data.get("series")))
        elif chart_type == "bar_with_line":
            has_data = bool(data.get("x_labels") or data.get("categories"))
        elif chart_type == "waterfall":
            has_data = bool(data.get("labels")) and bool(data.get("values"))
        else:
            has_data = bool(data)

        if not has_data:
            logger.warning(f"CHART_SKIP: '{title}' ({chart_type}) — no valid data, skipping")
            return

        fig, ax = plt.subplots(1, 1, figsize=(6.0, 4.0))

        if chart_type == "pie":
            _render_pie(ax, data)
        elif chart_type == "bar":
            _render_bar(ax, data, np)
        elif chart_type == "grouped_bar":
            _render_bar(ax, data, np)
        elif chart_type == "horizontal_bar":
            _render_horizontal_bar(ax, data)
        elif chart_type == "stacked_bar":
            _render_stacked_bar(ax, data, np)
        elif chart_type == "bar_with_line":
            _render_bar_with_line(ax, data, np, fig)
        elif chart_type == "waterfall":
            _render_waterfall(ax, data, np)
        else:
            # Fallback: try as bar
            _render_bar(ax, data, np)

        ax.set_title(title, fontsize=11, fontweight='bold', color=CHART_COLORS_HEX["primary"], pad=12)
        plt.tight_layout()

        buf = BytesIO()
        fig.savefig(buf, format='png', dpi=150, bbox_inches='tight', facecolor='white')
        plt.close(fig)
        buf.seek(0)

        doc.add_paragraph()
        doc.add_picture(buf, width=Inches(5.5))

        # Figure caption
        _figure_counter += 1
        cap = doc.add_paragraph()
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = cap.add_run(f"Figure {_figure_counter}: {title}")
        run.font.size = Pt(9)
        run.font.italic = True
        run.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

        # Insight caption (if provided)
        if chart_config.get("insight_caption"):
            cap2 = doc.add_paragraph()
            cap2.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run2 = cap2.add_run(chart_config["insight_caption"])
            run2.font.size = Pt(9)
            run2.font.italic = True
            run2.font.color.rgb = COLORS["neutral"]

        logger.info(f"CHART_RENDER: SUCCESS — Figure {_figure_counter}: '{title}' ({chart_type})")

    except ImportError as e:
        logger.error(f"CHART_RENDER: ImportError — {str(e)}")
    except Exception as e:
        logger.error(f"CHART_RENDER: {type(e).__name__}: {str(e)}")


def _render_pie(ax, data: dict) -> None:
    """Pie chart. Handles both labels/values format and series format."""
    labels = data.get("labels", [])
    values = data.get("values", [])

    # Fallback: if LLM used series format, extract from first series
    if not labels and data.get("series"):
        labels = data.get("categories", [])
        values = data["series"][0].get("values", []) if data["series"] else []
    # Fallback: if LLM used categories/values at top level
    if not labels and data.get("categories"):
        labels = data["categories"]

    colors = data.get("colors", PIE_COLORS[:len(values)])
    if not labels or not values or all(v == 0 for v in values):
        return
    wedges, texts, autotexts = ax.pie(
        values, labels=labels, autopct='%1.1f%%',
        colors=colors[:len(values)], startangle=90,
        textprops={'fontsize': 9})
    for autotext in autotexts:
        autotext.set_fontweight('bold')


def _render_bar(ax, data: dict, np) -> None:
    """Vertical bar / grouped bar."""
    categories = data.get("categories", [])
    series = data.get("series", [])
    if not categories or not series:
        return
    x = np.arange(len(categories))
    width = 0.8 / max(len(series), 1)
    colors = [CHART_COLORS_HEX["primary"], CHART_COLORS_HEX["secondary"],
              CHART_COLORS_HEX["tertiary"], CHART_COLORS_HEX["highlight"]]
    for i, s in enumerate(series):
        offset = (i - len(series) / 2 + 0.5) * width
        bar_color = s.get("color", colors[i % len(colors)])
        bars = ax.bar(x + offset, s["values"], width, label=s.get("name", ""), color=bar_color)
        # Value labels on top
        for bar in bars:
            height = bar.get_height()
            ax.annotate(f'{_format_chart_number(height, data.get("unit", ""))}',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3), textcoords="offset points",
                        ha='center', va='bottom', fontsize=8)
    ax.set_xticks(x)
    ax.set_xticklabels(categories, fontsize=9)
    if len(series) > 1:
        ax.legend(fontsize=8, loc='upper right')
    ax.set_ylim(bottom=0)


def _render_horizontal_bar(ax, data: dict) -> None:
    """Horizontal bar (sorted descending)."""
    categories = data.get("categories", [])
    series = data.get("series", [])
    if series:
        values = series[0].get("values", [])
        bar_color = series[0].get("color", CHART_COLORS_HEX["primary"])
    else:
        values = data.get("values", [])
        bar_color = CHART_COLORS_HEX["primary"]
    if not categories or not values:
        return
    # Truncate long labels
    labels = [c[:25] + "..." if len(c) > 25 else c for c in categories]
    ax.barh(labels, values, color=bar_color)
    for i, v in enumerate(values):
        ax.text(v, i, f' {_format_chart_number(v, data.get("unit", ""))}',
                va='center', fontsize=8)


def _render_stacked_bar(ax, data: dict, np) -> None:
    """Stacked bar chart."""
    x_labels = data.get("x_labels", data.get("categories", []))
    stacks = data.get("stacks", data.get("series", []))
    if not x_labels or not stacks:
        return
    x = np.arange(len(x_labels))
    bottom = np.zeros(len(x_labels))
    colors = [CHART_COLORS_HEX["scope1"], CHART_COLORS_HEX["scope2"],
              CHART_COLORS_HEX["scope3"], CHART_COLORS_HEX["highlight"]]
    for i, stack in enumerate(stacks):
        values = stack.get("values", [])
        color = stack.get("color", colors[i % len(colors)])
        ax.bar(x, values, bottom=bottom, label=stack.get("name", ""), color=color, width=0.6)
        bottom += np.array(values)
    # Total annotations
    for i, total in enumerate(bottom):
        ax.annotate(f'{_format_chart_number(total, data.get("unit", ""))}',
                    xy=(i, total), xytext=(0, 5), textcoords="offset points",
                    ha='center', fontsize=8, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels(x_labels, fontsize=9)
    ax.legend(fontsize=8, loc='upper right')
    ax.set_ylim(bottom=0)


def _render_bar_with_line(ax, data: dict, np, fig) -> None:
    """Dual-axis: bar (left Y) + line (right Y)."""
    x_labels = data.get("x_labels", data.get("categories", []))
    bar_values = data.get("bar_values", [])
    line_values = data.get("line_values", [])
    if not x_labels:
        return
    x = np.arange(len(x_labels))
    # Bar on primary axis
    if bar_values:
        ax.bar(x, bar_values, color=CHART_COLORS_HEX["primary"], width=0.5,
               label=data.get("bar_label", data.get("bar_unit", "Absolute")))
        ax.set_ylabel(data.get("bar_unit", ""), fontsize=9)
        ax.set_ylim(bottom=0)
    # Line on secondary axis
    if line_values:
        ax2 = ax.twinx()
        ax2.plot(x, line_values, color=CHART_COLORS_HEX["highlight"], marker='o',
                 linewidth=2, label=data.get("line_label", data.get("line_unit", "Intensity")))
        ax2.set_ylabel(data.get("line_unit", ""), fontsize=9, color=CHART_COLORS_HEX["highlight"])
        ax2.tick_params(axis='y', labelcolor=CHART_COLORS_HEX["highlight"])
        # Value labels on line
        for i, v in enumerate(line_values):
            ax2.annotate(f'{v:.1f}', xy=(i, v), xytext=(0, 8),
                         textcoords="offset points", ha='center', fontsize=8,
                         color=CHART_COLORS_HEX["highlight"], fontweight='bold')
        ax2.spines['top'].set_visible(False)
    ax.set_xticks(x)
    ax.set_xticklabels(x_labels, fontsize=9)


def _render_waterfall(ax, data: dict, np) -> None:
    """Waterfall chart showing YoY emission changes decomposition."""
    labels = data.get("labels", [])
    values = data.get("values", [])
    types = data.get("types", [])
    if not labels or not values:
        return
    n = len(labels)
    # Compute running total and bar positions
    running = 0
    bottoms = []
    bar_values = []
    bar_colors = []
    for i in range(n):
        if types[i] == "total":
            bottoms.append(0)
            bar_values.append(values[i])
            bar_colors.append(CHART_COLORS_HEX["primary"])
            running = values[i]
        else:  # delta
            if values[i] >= 0:
                bottoms.append(running)
                bar_colors.append(CHART_COLORS_HEX["negative"])  # Increase = bad (red)
            else:
                bottoms.append(running + values[i])
                bar_colors.append(CHART_COLORS_HEX["positive"])  # Decrease = good (green)
            bar_values.append(abs(values[i]))
            running += values[i]

    x = np.arange(n)
    bars = ax.bar(x, bar_values, bottom=bottoms, color=bar_colors, width=0.6)

    # Connector lines
    for i in range(n - 1):
        top_current = bottoms[i] + bar_values[i]
        ax.plot([i + 0.3, i + 0.7], [top_current, top_current],
                color='#999999', linewidth=0.8, linestyle='--')

    # Value labels
    for i, bar in enumerate(bars):
        height = bar.get_height()
        y_pos = bottoms[i] + height
        prefix = "+" if types[i] == "delta" and values[i] > 0 else ""
        label = f"{prefix}{_format_chart_number(values[i], data.get('unit', ''))}"
        ax.annotate(label, xy=(i, y_pos), xytext=(0, 4),
                    textcoords="offset points", ha='center', fontsize=8, fontweight='bold')

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8, rotation=15, ha='right')
    ax.set_ylim(bottom=0)


def _format_chart_number(value, unit: str = "") -> str:
    """Format numbers for chart labels."""
    if value is None:
        return "N/A"
    try:
        value = float(value)
    except (TypeError, ValueError):
        return str(value)
    if abs(value) >= 1_000_000:
        return f"{value / 1_000_000:.1f}M"
    elif abs(value) >= 1_000:
        return f"{value / 1_000:.1f}K"
    elif unit == "%":
        return f"{value:.1f}%"
    else:
        return f"{value:,.1f}"


# =============================================================================
# INSIGHT LAYER RENDERING
# =============================================================================

def _add_kpi_highlights(doc: Document, kpis: list[dict]) -> None:
    """Add KPI highlight boxes at top of section."""
    if not kpis:
        return
    num_kpis = min(len(kpis), 4)
    table = doc.add_table(rows=2, cols=num_kpis)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    for i, kpi in enumerate(kpis[:num_kpis]):
        # Value cell
        cell = table.rows[0].cells[i]
        _set_cell_shading(cell, "F2F6FA")
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(str(kpi.get("value", "")))
        run.font.size = Pt(18)
        run.font.bold = True
        run.font.color.rgb = COLORS["primary"]
        if kpi.get("unit"):
            run_unit = p.add_run(f" {kpi['unit']}")
            run_unit.font.size = Pt(9)
            run_unit.font.color.rgb = COLORS["neutral"]
        if kpi.get("trend_value"):
            trend = kpi.get("trend", "")
            color = COLORS["negative"] if trend in ("up", "warning") else COLORS["positive"]
            run_trend = p.add_run(f"\n{kpi['trend_value']}")
            run_trend.font.size = Pt(10)
            run_trend.font.bold = True
            run_trend.font.color.rgb = color

        # Label cell
        label_cell = table.rows[1].cells[i]
        _set_cell_shading(label_cell, "F2F6FA")
        lp = label_cell.paragraphs[0]
        lp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run_label = lp.add_run(kpi.get("label", ""))
        run_label.font.size = Pt(8)
        run_label.font.color.rgb = COLORS["neutral"]

    doc.add_paragraph()


def _add_insight_box(doc: Document, insight: dict | str) -> None:
    """Add styled insight box with severity-based coloring."""
    if isinstance(insight, str):
        insight = {"headline": insight, "severity": "warning"}
    severity = insight.get("severity", "info")

    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.rows[0].cells[0]

    bg_map = {"info": "E3F2FD", "warning": "FFF8E1", "critical": "FFEBEE", "positive": "E8F5E9"}
    icon_map = {"info": "💡", "warning": "⚠️", "critical": "🚨", "positive": "✅"}

    _set_cell_shading(cell, bg_map.get(severity, "FFF8E1"))

    p = cell.paragraphs[0]
    run_header = p.add_run(f"{icon_map.get(severity, '⚠️')} KEY INSIGHT")
    run_header.font.size = Pt(9)
    run_header.font.bold = True
    run_header.font.color.rgb = COLORS["highlight"]

    p2 = cell.add_paragraph()
    run_hl = p2.add_run(insight.get("headline", ""))
    run_hl.font.size = Pt(11)
    run_hl.font.bold = True

    if insight.get("body"):
        p3 = cell.add_paragraph()
        run_body = p3.add_run(insight["body"])
        run_body.font.size = Pt(10)

    doc.add_paragraph()


def _add_diagnostic_box(doc: Document, text: str, root_causes: list = None, risk_implications: list = None) -> None:
    """Add diagnostic analysis box with navy left-border styling."""
    table = doc.add_table(rows=1, cols=1)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = table.rows[0].cells[0]
    _set_cell_shading(cell, "F2F6FA")

    p = cell.paragraphs[0]
    run_header = p.add_run("📊 DIAGNOSTIC ANALYSIS")
    run_header.font.size = Pt(9)
    run_header.font.bold = True
    run_header.font.color.rgb = COLORS["primary"]

    p2 = cell.add_paragraph()
    run_body = p2.add_run(text)
    run_body.font.size = Pt(10)

    if root_causes:
        p_rc = cell.add_paragraph()
        run_rc = p_rc.add_run("Root Causes:")
        run_rc.font.bold = True
        run_rc.font.size = Pt(10)
        for cause in root_causes:
            p_c = cell.add_paragraph(f"• {cause}")
            for run in p_c.runs:
                run.font.size = Pt(9)

    if risk_implications:
        p_ri = cell.add_paragraph()
        run_ri = p_ri.add_run("Risk Implications:")
        run_ri.font.bold = True
        run_ri.font.size = Pt(10)
        for risk in risk_implications:
            p_r = cell.add_paragraph(f"• {risk}")
            for run in p_r.runs:
                run.font.size = Pt(9)

    doc.add_paragraph()


def _add_priority_actions(doc: Document, actions: list[dict]) -> None:
    """Add priority actions callout."""
    if not actions:
        return
    doc.add_paragraph()
    p_header = doc.add_paragraph()
    run = p_header.add_run("⚡ Priority Actions")
    run.font.bold = True
    run.font.size = Pt(STYLE["font_size_h3"])
    run.font.color.rgb = COLORS["positive"]

    for i, action in enumerate(actions, 1):
        priority_icon = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(action.get("priority", "medium"), "⚪")
        p = doc.add_paragraph()
        run_action = p.add_run(f"{priority_icon} {i}. {action.get('action', '')}")
        run_action.font.bold = True
        run_action.font.size = Pt(STYLE["font_size_body"])
        if action.get("timeline"):
            run_tl = p.add_run(f" ({action['timeline']})")
            run_tl.font.size = Pt(STYLE["font_size_body"])
        if action.get("expected_impact"):
            p2 = doc.add_paragraph(f"    → Expected: {action['expected_impact']}")
            _apply_paragraph_format(p2)
        if action.get("peer_reference"):
            p3 = doc.add_paragraph(f"    → Ref: {action['peer_reference']}")
            _style_paragraph_type(p3, "footnote")

    doc.add_paragraph()


# =============================================================================
# TABLE STYLING (REQ-ASSY-03)
# =============================================================================

def _add_esg_table(doc: Document, table_data: dict[str, Any]) -> None:
    """Add ESG-styled table with navy header and alternating rows."""
    global _table_counter
    caption = table_data.get("caption", "")
    headers = table_data.get("headers", [])
    rows = table_data.get("rows", [])
    source_note = table_data.get("source_note", "")

    if not headers:
        return

    if caption:
        _table_counter += 1
        cap_p = doc.add_paragraph()
        run = cap_p.add_run(f"Table {_table_counter}: {caption}")
        run.font.bold = True
        run.font.size = Pt(10)
        run.font.name = STYLE["font_body"]

    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # Header row
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        cell.text = str(header)
        _set_cell_shading(cell, "1B3A6B")
        for run in cell.paragraphs[0].runs:
            run.font.bold = True
            run.font.size = Pt(STYLE["font_size_table"])
            run.font.name = STYLE["font_body"]
            run.font.color.rgb = COLORS["white"]

    # Data rows
    for row_idx, row_data in enumerate(rows):
        for col_idx, cell_value in enumerate(row_data):
            if col_idx >= len(headers):
                break
            cell = table.rows[row_idx + 1].cells[col_idx]
            str_val = str(cell_value) if cell_value is not None else ""
            cell.text = str_val
            para = cell.paragraphs[0]
            if _is_numeric(str_val):
                para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            for run in para.runs:
                run.font.size = Pt(STYLE["font_size_table"])
                run.font.name = STYLE["font_body"]
            if row_idx % 2 == 1:
                _set_cell_shading(cell, "F2F6FC")

    if source_note:
        note_p = doc.add_paragraph()
        run = note_p.add_run(f"Source: {source_note}")
        run.font.size = Pt(8)
        run.font.italic = True
        run.font.name = STYLE["font_body"]

    doc.add_paragraph()


# =============================================================================
# COVER PAGE, TOC, APPENDICES
# =============================================================================

def _add_cover_page(doc: Document, bank_id: str, framework: str, year: int,
                    timestamp: datetime, execution_id: str) -> None:
    """Add formatted cover page."""
    doc.add_paragraph()
    p_logo = doc.add_paragraph("[INSTITUTION LOGO]")
    p_logo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in p_logo.runs:
        run.font.size = Pt(12)
        run.font.color.rgb = RGBColor(0x99, 0x99, 0x99)

    doc.add_paragraph()
    doc.add_paragraph()

    title = doc.add_heading("ESG Sustainability Report", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _style_heading(title, level=1)

    subtitle = doc.add_heading(f"Reporting Year {year}", level=2)
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _style_heading(subtitle, level=2)

    doc.add_paragraph()

    meta_items = [
        ("Institution", bank_id),
        ("Framework", framework),
        ("Generated", timestamp.strftime("%Y-%m-%d %H:%M UTC")),
        ("Status", "DRAFT — Subject to Review"),
        ("Assurance Level", "None"),
    ]
    for label, value in meta_items:
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(f"{label}: {value}")
        run.font.name = STYLE["font_body"]
        run.font.size = Pt(STYLE["font_size_body"])

    doc.add_paragraph()
    doc.add_paragraph()

    conf = doc.add_paragraph()
    conf.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = conf.add_run(
        "CONFIDENTIAL — This document is for internal review purposes only. "
        "Do not distribute without authorization.")
    run.font.size = Pt(9)
    run.font.italic = True
    run.font.color.rgb = RGBColor(0x99, 0x33, 0x33)

    doc.add_page_break()


def _add_toc(doc: Document) -> None:
    """Add Table of Contents field code."""
    toc_heading = doc.add_heading("Table of Contents", level=1)
    _style_heading(toc_heading, level=1)

    paragraph = doc.add_paragraph()
    run = paragraph.add_run()
    fld_char_begin = OxmlElement("w:fldChar")
    fld_char_begin.set(qn("w:fldCharType"), "begin")
    run._r.append(fld_char_begin)

    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = ' TOC \\o "1-3" \\h \\z \\u '
    run._r.append(instr)

    fld_char_sep = OxmlElement("w:fldChar")
    fld_char_sep.set(qn("w:fldCharType"), "separate")
    run._r.append(fld_char_sep)

    run2 = paragraph.add_run("Table of Contents — Update this field (Ctrl+A → F9)")
    run2.font.color.rgb = RGBColor(0x99, 0x99, 0x99)
    run2.font.italic = True

    run3 = paragraph.add_run()
    fld_char_end = OxmlElement("w:fldChar")
    fld_char_end.set(qn("w:fldCharType"), "end")
    run3._r.append(fld_char_end)

    doc.add_page_break()


def _add_appendices(doc: Document, sections: list[dict], framework: str) -> None:
    """Add comprehensive appendix sections (Phase 3)."""

    # === APPENDIX A: Methodology & Calculation Approach ===
    doc.add_page_break()
    h = doc.add_heading("Appendix A: Methodology & Calculation Approach", level=1)
    _style_heading(h, level=1)

    _add_formatted_paragraph(doc, "**A.1 Reporting Boundary & Consolidation**")
    _add_esg_table(doc, {
        "caption": "Reporting Parameters",
        "headers": ["Parameter", "Value"],
        "rows": [
            ["Consolidation Approach", "Operational Control (per GHG Protocol)"],
            ["Organizational Boundary", "All facilities under operational control"],
            ["Reporting Period", "01 January – 31 December (annual)"],
            ["Base Year", "2023 (first year of comprehensive GHG inventory)"],
            ["Recalculation Policy", "Triggered if structural changes affect >5% of total"],
            ["Standards Applied", "GHG Protocol Corporate Standard (2015 Revised)"],
            ["Financed Emissions", "PCAF Global Standard Part A (2022 Revision)"],
        ],
    })

    _add_formatted_paragraph(doc, "**A.2 Scope 1 — Direct Emissions**")
    p = doc.add_paragraph(
        "Scope 1 covers stationary combustion (diesel generators, natural gas boilers) and "
        "mobile combustion (company fleet vehicles). Calculation method: fuel-based approach "
        "(activity data × emission factor). Emission factors sourced from UK DEFRA 2024/2025 "
        "conversion factors. GWP values from IPCC Sixth Assessment Report (AR6, 100-year): "
        "CO₂ = 1.0, CH₄ = 29.8, N₂O = 273.0.")
    _apply_paragraph_format(p)

    _add_esg_table(doc, {
        "caption": "Scope 1 Emission Factors Applied",
        "headers": ["Fuel Type", "CO₂ Factor", "CH₄ Factor", "N₂O Factor", "Source"],
        "rows": [
            ["Diesel", "2.6710 kg/L", "0.00029 kgCO₂e/L", "0.03308 kgCO₂e/L", "DEFRA 2025"],
            ["Natural Gas", "56.10 kg/GJ", "0.0298 kgCO₂e/GJ", "0.0273 kgCO₂e/GJ", "IPCC AR6"],
        ],
    })

    _add_formatted_paragraph(doc, "**A.3 Scope 2 — Indirect Emissions**")
    p = doc.add_paragraph(
        "Scope 2 covers purchased electricity. Dual reporting: location-based (grid average "
        "emission factor) and market-based (contractual instruments). Grid emission factor: "
        "PLN National Grid Average per DJK-ESDM Ministerial Decree. RECs deducted from "
        "market-based calculation only.")
    _apply_paragraph_format(p)

    _add_esg_table(doc, {
        "caption": "Scope 2 Grid Emission Factors",
        "headers": ["Grid Region", "EF (kgCO₂/kWh)", "Source", "Year"],
        "rows": [
            ["PLN National Grid (Indonesia)", "0.7886", "DJK-ESDM", "2023"],
        ],
    })

    _add_formatted_paragraph(doc, "**A.4 Scope 3 Category 15 — Financed Emissions (PCAF)**")
    p = doc.add_paragraph(
        "Financed emissions calculated per PCAF Global GHG Accounting Standard Part A (2022). "
        "Asset class: business loans and project finance. Attribution formula: "
        "Financed Emissions = Σ (Attribution Factor × Borrower Scope 1+2 Emissions). "
        "Attribution Factor = Outstanding Amount / (Total Equity + Total Debt). "
        "Capped at 1.0 per REQ-ETL-19.")
    _apply_paragraph_format(p)

    _add_esg_table(doc, {
        "caption": "PCAF Confidence Weighting Factors",
        "headers": ["PCAF Score", "Description", "Confidence Factor", "Uncertainty"],
        "rows": [
            ["1.0", "Verified (CDP/equivalent)", "1.00", "±5%"],
            ["1.5", "Audited, unverified", "0.95", "±10%"],
            ["2.0", "Physical activity-based", "0.90", "±15%"],
            ["3.0", "EEIO + revenue-based", "0.75", "±25%"],
            ["4.0", "EEIO + asset-based", "0.60", "±40%"],
            ["5.0", "Sector-average proxy", "0.45", "±55%"],
        ],
    })

    _add_formatted_paragraph(doc, "**A.5 Intensity Metrics**")
    _add_esg_table(doc, {
        "caption": "Intensity Metric Definitions",
        "headers": ["Metric", "Formula", "Scope", "Denominator Source"],
        "rows": [
            ["Revenue Intensity", "Total Emissions / Revenue", "Scope 1+2+3", "Audited financial statements"],
            ["FTE Intensity", "Operational Emissions / FTE", "Scope 1+2 only", "HR system headcount"],
        ],
    })

    # === APPENDIX B: Data Quality & Assurance ===
    doc.add_page_break()
    h2 = doc.add_heading("Appendix B: Data Quality & Assurance Statement", level=1)
    _style_heading(h2, level=1)

    p = doc.add_paragraph(
        "Data quality is assessed using the PCAF data quality scoring framework (1-5) "
        "for financed emissions and GHG Protocol quality indicators for operational emissions. "
        "This report has NOT been subject to external assurance. Third-party limited assurance "
        "is recommended for future reporting cycles.")
    _apply_paragraph_format(p)

    _add_esg_table(doc, {
        "caption": "Operational Data Quality Assessment",
        "headers": ["Quality Tier", "Criteria", "Description"],
        "rows": [
            ["1 (High)", "0 imputed months", "Complete primary data from smart meters"],
            ["2 (Good)", "1-2 imputed months", "Minor gaps filled with facility-type avg"],
            ["3 (Moderate)", "3-5 imputed months", "Significant estimation required"],
            ["4 (Low)", "6+ imputed months", "Majority estimated — improvement needed"],
        ],
    })

    p2 = doc.add_paragraph(
        "Improvement Plan: Target 100% smart meter coverage across all facilities by Q4 2025. "
        "Monthly automated data ingestion via utility API integration in development.")
    _apply_paragraph_format(p2)

    # === APPENDIX C: Sector Classification ===
    doc.add_page_break()
    h3 = doc.add_heading("Appendix C: Sector Classification & PCAF Mapping", level=1)
    _style_heading(h3, level=1)

    p = doc.add_paragraph(
        "Sector classification follows NACE Rev. 2 codes mapped to PCAF asset classes. "
        "All productive loans in the portfolio are classified into one of the sectors below.")
    _apply_paragraph_format(p)

    _add_esg_table(doc, {
        "caption": "PCAF Sector Classification",
        "headers": ["NACE Code", "Sector", "PCAF Asset Class", "Emission Factor Source"],
        "rows": [
            ["B.06", "Energy — Oil & Gas", "Business Loans", "CDP / Company Reports"],
            ["C.23", "Manufacturing — Cement", "Business Loans", "EEIO (Exiobase)"],
            ["C.24", "Manufacturing — Steel", "Business Loans", "EEIO (Exiobase)"],
            ["C.10", "Manufacturing — Food", "Business Loans", "EEIO (Exiobase)"],
            ["L.68", "Real Estate — Commercial", "Commercial Real Estate", "Building EPC"],
            ["L.68.2", "Real Estate — Residential", "Mortgages", "Building EPC"],
            ["H.49", "Transportation — Road", "Business Loans", "Company Reports"],
            ["A.01", "Agriculture", "Business Loans", "EEIO (Exiobase)"],
            ["G.47", "Retail Trade", "Business Loans", "EEIO (Exiobase)"],
            ["K.64", "Financial Services", "Business Loans", "Company Reports"],
        ],
    })

    # === APPENDIX D: GRI Content Index ===
    if framework in ("GRI_305", "MULTI_FRAMEWORK"):
        doc.add_page_break()
        h4 = doc.add_heading("Appendix D: GRI Content Index", level=1)
        _style_heading(h4, level=1)

        p = doc.add_paragraph(
            "This report has been prepared with reference to the GRI Standards (2021). "
            "GRI 102: Climate Change 2025 supersedes GRI 305 effective 1 January 2027.")
        _apply_paragraph_format(p)

        _add_esg_table(doc, {
            "caption": "GRI Standards Content Index",
            "headers": ["GRI Standard", "Disclosure", "Section", "Status"],
            "rows": [
                ["GRI 2-7", "Employees", "Social", "✅ Disclosed"],
                ["GRI 305-1", "Direct (Scope 1) GHG emissions", "Scope 1", "✅ Disclosed"],
                ["GRI 305-1a", "Gross Scope 1 in tCO₂e", "Scope 1", "✅ Disclosed"],
                ["GRI 305-1b", "Gases included (CO₂, CH₄, N₂O)", "Scope 1", "✅ Disclosed"],
                ["GRI 305-1e", "Emission factors & GWP source", "Appendix A", "✅ Disclosed"],
                ["GRI 305-1f", "Consolidation approach", "Appendix A", "✅ Disclosed"],
                ["GRI 305-1g", "Standards used", "Appendix A", "✅ Disclosed"],
                ["GRI 305-2", "Energy indirect (Scope 2)", "Scope 2", "✅ Disclosed"],
                ["GRI 305-2a", "Location-based + Market-based", "Scope 2", "✅ Disclosed"],
                ["GRI 305-3", "Other indirect (Scope 3)", "PCAF / Scope 3", "✅ Disclosed"],
                ["GRI 305-3a", "Category 15: Investments (PCAF)", "PCAF / Scope 3", "✅ Disclosed"],
                ["GRI 305-4", "GHG emissions intensity", "Intensity", "✅ Disclosed"],
                ["GRI 305-5", "Reduction of GHG emissions", "Reduction", "⚠️ Partial"],
                ["GRI 401-1", "New hires and turnover", "Social", "✅ Disclosed"],
                ["GRI 404-1", "Training hours per employee", "Social", "✅ Disclosed"],
                ["GRI 405-1", "Diversity of governance bodies", "Social", "✅ Disclosed"],
                ["GRI 406-1", "Discrimination incidents", "Social", "✅ Disclosed"],
            ],
            "source_note": "GRI Standards 2021. Note: GRI 102 (2025) supersedes GRI 305 from 2027."
        })

    # === APPENDIX E: Framework Disclosure Cross-Reference ===
    if framework == "MULTI_FRAMEWORK":
        doc.add_page_break()
        h5 = doc.add_heading("Appendix E: Framework Disclosure Cross-Reference", level=1)
        _style_heading(h5, level=1)

        p = doc.add_paragraph(
            "This report simultaneously addresses requirements from four sustainability "
            "reporting frameworks. The table below maps report sections to specific "
            "disclosure requirements per framework.")
        _apply_paragraph_format(p)

        _add_esg_table(doc, {
            "caption": "Multi-Framework Disclosure Mapping",
            "headers": ["Report Section", "GRI 305", "IFRS S2", "ESRS E1", "OJK PSPK"],
            "rows": [
                ["Scope 1 Emissions", "305-1 (a-g)", "Para 29(a)(i)", "DR E1-6 §44", "Lampiran II.A.1"],
                ["Scope 2 Emissions", "305-2 (a-e)", "Para 29(a)(ii)", "DR E1-6 §47-48", "Lampiran II.A.2"],
                ["Scope 3 / Financed", "305-3 (a-f)", "Para 29(a)(iv)", "DR E1-6 §51-54", "Lampiran II.A.3"],
                ["Intensity", "305-4 (a-d)", "Para 29(b)", "DR E1-6 §55-56", "Lampiran II.B"],
                ["Reduction Targets", "305-5 (a-e)", "Para 33-36", "DR E1-4 §34-42", "Lampiran II.C"],
                ["Governance", "N/A", "Para 5-9", "ESRS 2 GOV-1", "Lampiran I"],
                ["Transition Plan", "N/A", "Para 14-15", "DR E1-1 §14-19", "Lampiran III"],
                ["Social Metrics", "401/404/405/406", "N/A", "ESRS S1", "Lampiran IV"],
            ],
            "source_note": "Cross-reference per framework publication (GRI 2021, IFRS S2 2023, ESRS 2023, POJK 51/2017)"
        })

    # === APPENDIX F: Glossary ===
    doc.add_page_break()
    h6 = doc.add_heading("Appendix F: Glossary of Terms & Abbreviations", level=1)
    _style_heading(h6, level=1)

    _add_esg_table(doc, {
        "caption": "Glossary",
        "headers": ["Term / Abbreviation", "Definition"],
        "rows": [
            ["tCO₂e", "Tonnes of carbon dioxide equivalent"],
            ["GHG", "Greenhouse Gas"],
            ["GWP", "Global Warming Potential (100-year, IPCC AR6)"],
            ["PCAF", "Partnership for Carbon Accounting Financials"],
            ["SBTi", "Science Based Targets initiative"],
            ["NZBA", "Net-Zero Banking Alliance"],
            ["NDC", "Nationally Determined Contribution (Paris Agreement)"],
            ["RECs", "Renewable Energy Certificates"],
            ["PPA", "Power Purchase Agreement"],
            ["EF", "Emission Factor"],
            ["FTE", "Full-Time Equivalent (headcount)"],
            ["YoY", "Year-over-Year"],
            ["EEIO", "Environmentally Extended Input-Output (model)"],
            ["GRI", "Global Reporting Initiative"],
            ["IFRS S2", "IFRS Sustainability Disclosure Standard S2 (Climate)"],
            ["ESRS E1", "European Sustainability Reporting Standard E1 (Climate Change)"],
            ["CSRD", "Corporate Sustainability Reporting Directive (EU)"],
            ["OJK", "Otoritas Jasa Keuangan (Financial Services Authority, Indonesia)"],
            ["POJK", "Peraturan Otoritas Jasa Keuangan (OJK Regulation)"],
            ["PSPK", "Penerapan Keuangan Berkelanjutan (Sustainable Finance Implementation)"],
            ["PLN", "Perusahaan Listrik Negara (State Electricity Company, Indonesia)"],
            ["DJK-ESDM", "Directorate General of Electricity, Ministry of Energy"],
        ],
        "source_note": "Compiled from GHG Protocol, PCAF Standard, and regulatory publications"
    })


# =============================================================================
# STYLING HELPERS
# =============================================================================

def _style_heading(heading, level: int = 1) -> None:
    """Apply heading style."""
    heading.paragraph_format.keep_with_next = True
    if level == 1:
        heading.paragraph_format.space_before = Pt(STYLE["spacing_before_h1_pt"])
        heading.paragraph_format.space_after = Pt(STYLE["spacing_after_h1_pt"])
    elif level == 2:
        heading.paragraph_format.space_before = Pt(STYLE["spacing_before_h2_pt"])
        heading.paragraph_format.space_after = Pt(STYLE["spacing_after_h2_pt"])
    color_map = {1: COLORS["primary"], 2: COLORS["secondary"], 3: COLORS["tertiary"]}
    size_map = {1: STYLE["font_size_h1"], 2: STYLE["font_size_h2"], 3: STYLE["font_size_h3"]}
    for run in heading.runs:
        run.font.name = STYLE["font_heading"]
        run.font.bold = True
        run.font.size = Pt(size_map.get(level, 12))
        run.font.color.rgb = color_map.get(level, COLORS["tertiary"])


def _apply_paragraph_format(para) -> None:
    """Apply standard body paragraph formatting."""
    para.paragraph_format.space_after = Pt(STYLE["spacing_after_body_pt"])
    para.paragraph_format.line_spacing = STYLE["line_spacing"]


def _style_paragraph_type(para, para_type: str = "narrative") -> None:
    """Apply paragraph styling by type."""
    _apply_paragraph_format(para)
    for run in para.runs:
        run.font.name = STYLE["font_body"]
        run.font.size = Pt(STYLE["font_size_body"])
        if para_type == "footnote":
            run.font.size = Pt(STYLE["font_size_footnote"])
            run.font.italic = True
            run.font.color.rgb = RGBColor(0x64, 0x64, 0x64)
        elif para_type == "methodology":
            run.font.italic = True


def _set_cell_shading(cell, color_hex: str) -> None:
    """Apply background color to table cell."""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), color_hex)
    shading.set(qn("w:val"), "clear")
    tcPr.append(shading)


def _add_horizontal_rule(doc: Document) -> None:
    """Add horizontal rule."""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(4)
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "CCCCCC")
    pBdr.append(bottom)
    pPr.append(pBdr)


def _add_page_number_field(paragraph) -> None:
    """Add Page X of Y field."""
    run = paragraph.add_run("Page ")
    run.font.size = Pt(STYLE["font_size_header_footer"])
    run.font.color.rgb = COLORS["footer"]

    fld1 = OxmlElement("w:fldChar")
    fld1.set(qn("w:fldCharType"), "begin")
    instr1 = OxmlElement("w:instrText")
    instr1.set(qn("xml:space"), "preserve")
    instr1.text = " PAGE "
    fld2 = OxmlElement("w:fldChar")
    fld2.set(qn("w:fldCharType"), "end")
    run2 = paragraph.add_run()
    run2._r.append(fld1)
    run2._r.append(instr1)
    run2._r.append(fld2)
    run2.font.size = Pt(STYLE["font_size_header_footer"])
    run2.font.color.rgb = COLORS["footer"]

    run3 = paragraph.add_run(" of ")
    run3.font.size = Pt(STYLE["font_size_header_footer"])
    run3.font.color.rgb = COLORS["footer"]

    fld3 = OxmlElement("w:fldChar")
    fld3.set(qn("w:fldCharType"), "begin")
    instr2 = OxmlElement("w:instrText")
    instr2.set(qn("xml:space"), "preserve")
    instr2.text = " NUMPAGES "
    fld4 = OxmlElement("w:fldChar")
    fld4.set(qn("w:fldCharType"), "end")
    run4 = paragraph.add_run()
    run4._r.append(fld3)
    run4._r.append(instr2)
    run4._r.append(fld4)
    run4.font.size = Pt(STYLE["font_size_header_footer"])
    run4.font.color.rgb = COLORS["footer"]


# =============================================================================
# UTILITIES
# =============================================================================

def _sort_sections(sections: list[dict], order: list[str]) -> list[dict]:
    """Sort sections by framework-defined order."""
    order_map = {s: i for i, s in enumerate(order)}
    return sorted(sections, key=lambda s: order_map.get(_extract_section_type(s.get("section_id", "")), 999))


def _extract_section_type(section_id: str) -> str:
    """Extract section type from section_id."""
    sid = section_id.lower()
    if "unified" in sid:
        if "scope1" in sid: return "scope1"
        if "scope2" in sid: return "scope2"
        if "pcaf" in sid or "scope3" in sid: return "scope3_pcaf"
        if "intensity" in sid: return "intensity"
        if "reduction" in sid: return "reduction"
        if "social" in sid: return "social"
        if "governance" in sid: return "governance"
        if "targets" in sid: return "targets"
    if "scope1" in sid or "_s1_" in sid: return "scope1"
    if "scope2" in sid or "_s2_" in sid: return "scope2"
    if "pcaf" in sid or "scope3" in sid or "_s3_" in sid: return "scope3_pcaf"
    if "intensity" in sid: return "intensity"
    if "social" in sid: return "social"
    if "reduction" in sid or "305-5" in sid: return "reduction"
    if "summary" in sid: return "summary"
    if "gov" in sid: return "governance"
    if "target" in sid: return "targets"
    return "unknown"


def _is_numeric(val: str) -> bool:
    """Check if string value is numeric."""
    try:
        float(val.replace(",", "").replace("%", ""))
        return True
    except (ValueError, AttributeError):
        return False
